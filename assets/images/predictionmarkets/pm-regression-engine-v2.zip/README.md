# Polymarket → TradFi Regression Engine

A standalone local Python pipeline that discovers financial/macro prediction markets on Polymarket, maps them to tradable TradFi assets, and runs a LASSO-based regression analysis to identify statistically significant sentiment signals. It also supports a broader TradFi correlation engine that evaluates Polymarket markets against a configurable universe of TradFi tickers, plus a regulatory plausibility filter for Ontario/Canada context.

## Architecture Overview

```
Phase 1: Market Discovery    → Fetch & filter Polymarket markets (Gamma API)
Phase 2: Semantic Mapping     → LLM + embeddings map markets → tickers (cached)
Phase 3: Data Ingestion       → Pull 5-min bars from yfinance + CLOB price history
Phase 4: Feature Engineering  → Align, logit-transform, lag, stationarity checks
Phase 5: Statistical Engine   → LASSO CV → Post-LASSO OLS (HAC) → Granger → OOS
Phase 6: Library Persistence  → SQLite + JSON/Excel exports
Phase 7: Correlation Analysis  → Many-to-many market/ticker scoring vs TradFi universe
```
Each phase is idempotent and restartable. Intermediate results are cached so you can re-run from any phase.

## Quick Start

### 1. Clone and set up the environment

```bash
cd pm-regression-engine
python -m venv .venv
source .venv/bin/activate      # macOS/Linux
# .venv\Scripts\activate       # Windows

pip install -r requirements.txt
```

### 2. Configure secrets

```bash
cp .env.example .env
# Edit .env and set your OPENAI_API_KEY (required for Phase 2 LLM mapping)
```

### 3. Review config.yaml

The defaults are sensible for initial runs. Key settings to consider:

- `polymarket.max_markets_per_run`: How many markets to fetch (default 2000)
- `tradfi.lookback_days`: How far back to pull 5-min data (default 14, max 59)
- `tradfi.universe`: Optional list of TradFi tickers to use for broader correlation analysis
- `llm.dry_run`: Set to `true` to preview mappings without calling the LLM
- `general.debug_save_intermediates`: Set to `true` to save CSVs at each phase

### 4. Initialize the database

```bash
python -m src.cli init-db
```

### 5. Run the pipeline

**New unified interface:**

```bash
python -m src.cli run --function lasso          # Full LASSO pipeline for all mapped tickers
python -m src.cli run --function lasso --ticker SPY   # Full pipeline for a single ticker
python -m src.cli run --function correlation --output results.xlsx
python -m src.cli run --function regulatory-filter
```

**Smoke test (quick validation):**

```bash
python -m src.cli run --function lasso --smoke-test
```

This limits to ~50 markets, 3-day lookback, and relaxed observation thresholds.

### 6. Inspect results

```bash
python -m src.cli inspect --ticker SPY    # Detailed report for a ticker
python -m src.cli summary                 # High-level DB summary
python -m src.cli export-library          # Export JSON + Excel
```

## CLI Reference

| Command | Description |
|---------|-------------|
| `init-db` | Create/update SQLite schema |
| `run-phase --phase N` | Run a single phase (1-6) |
| `run --function lasso [--ticker X]` | Run the full LASSO pipeline for all mapped tickers, or a single ticker if `--ticker` is provided |
| `run-pipeline --ticker X` | Legacy single-ticker full pipeline (phases 3-6) |
| `run-pipeline-all` | Legacy full pipeline for all mapped tickers |
| `run --function correlation [--output path]` | Run broader correlation analysis across TradFi tickers |
| `run --function regulatory-filter` | Run Ontario/Canada regulatory plausibility assessment |
| `run-pipeline-all --smoke-test` | Quick smoke test with limited scope |
| `inspect --ticker X` | Diagnostic report for a ticker |
| `summary` | Database overview |
| `export-library` | Export to JSON and Excel |

All commands accept `--config /path/to/config.yaml` to use a custom config file.

## Project Structure

```
pm-regression-engine/
├── README.md
├── requirements.txt
├── .env.example
├── config.yaml
├── data/
│   ├── raw/              # Raw API pulls (when debug enabled)
│   ├── processed/        # Aligned feature DataFrames (when debug enabled)
│   └── debug/
│       └── llm_cache/    # Cached LLM responses (never re-query same market)
├── db/
│   └── pm_sentiment_engine.db   # SQLite database (created at runtime)
├── exports/
│   ├── json/             # verified_relationships.json
│   └── excel/            # library_snapshot.xlsx (styled, conditional formatting)
├── logs/
│   └── engine.log        # Rotating log file
├── src/
│   ├── __init__.py
│   ├── __main__.py       # python -m src entry point
│   ├── cli.py            # Click-based CLI
│   ├── config_loader.py  # YAML + .env loading with Pydantic validation
│   ├── db.py             # SQLite layer with migration-safe schema
│   ├── diagnostics.py    # inspect, summary, sanity checks
│   ├── embeddings_dedup.py  # Sentence-transformer deduplication
│   ├── feature_engineering.py  # Alignment, logit, lags, stationarity
│   ├── filters.py        # Tag, keyword, volume filters
│   ├── library_export.py # JSON + styled Excel export
│   ├── llm_mapper.py     # OpenAI mapping with file-based cache
│   ├── logging_utils.py  # Loguru setup (console + rotating file)
│   ├── main.py           # Pipeline orchestration (phases 1-6)
│   ├── modeling.py        # LASSO, post-LASSO OLS, Granger, OOS
│   ├── polymarket_client.py  # Gamma + CLOB API client
│   └── tradfi_client.py  # yfinance wrapper
└── tests/
    ├── test_smoke.py              # DB, config, CLI, filter tests
    ├── test_feature_alignment.py  # Alignment and feature computation
    └── test_modeling_small_sample.py  # LASSO, OLS, status classification
```

## Status Tiers

Each ticker is classified into one of four tiers after modeling:

| Status | Criteria |
|--------|----------|
| **Null** | No non-zero LASSO coefficients, or p-values too high |
| **Candidate** | At least one beta with p < 0.10 |
| **Verified** | Candidate + Granger p < 0.05 + OOS IC > 0.05 + OOS Sharpe > 0.5 + n ≥ 500 |
| **Degraded** | Was Verified but no longer meets thresholds |

## Statistical Methods

1. **LASSO with TimeSeriesSplit CV**: Prevents look-ahead bias; selects sparse feature set
2. **Post-LASSO OLS with HAC (Newey-West) errors**: Robust standard errors for autocorrelated residuals
3. **Granger causality tests**: Tests whether PM logit changes Granger-cause TradFi returns
4. **Walk-forward OOS validation**: Train on first 67%, test on last 33%; computes IC and long/short Sharpe

## LLM Usage & Caching

The LLM is called **only once per market** — results are cached in `data/debug/llm_cache/`. Subsequent runs skip already-mapped markets entirely. To preview without spending tokens, set `llm.dry_run: true` in config.yaml.

## Debugging

- **Logs**: `logs/engine.log` captures DEBUG-level messages with timestamps
- **Intermediate CSVs**: Set `general.debug_save_intermediates: true` to save data at each phase
- **LLM cache**: Inspect `data/debug/llm_cache/*.json` to see raw LLM responses
- **SQLite**: Open `db/pm_sentiment_engine.db` with any SQLite browser

## Running Tests

```bash
cd pm-regression-engine
python -m pytest tests/ -v
```

## Troubleshooting

- **"No data returned for ticker X"**: yfinance may not support that ticker, or markets are closed
- **"Too few observations"**: Increase `tradfi.lookback_days` or lower `tradfi.min_effective_observations`
- **LLM errors**: Check `OPENAI_API_KEY` in `.env`; inspect `data/debug/llm_cache/` for raw responses
- **Ctrl+C is safe**: The SQLite WAL mode ensures DB consistency even on interruption
