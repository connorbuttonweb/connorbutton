"""
correlation_engine.py — Correlation analysis between Polymarket sentiment and TradFi assets.

Computes Pearson/Spearman correlations between Polymarket markets and a broader TradFi ticker universe.
Exports significant market-ticker pairs to Excel/JSON.
"""

from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Dict, Any, List, Optional, Tuple
import json

import pandas as pd
from scipy.stats import pearsonr, spearmanr

from src.config_loader import AppConfig, find_project_root
from src.db import Database
from src.logging_utils import get_logger
from src.tradfi_client import TradFiClient
from src.polymarket_client import PolymarketClient

log = get_logger("correlation_engine")


def _get_candidate_tickers(cfg: AppConfig, db: Database) -> List[str]:
    """Build an ordered list of TradFi tickers to compute correlations against."""
    candidates = []
    if cfg.tradfi.universe:
        candidates.extend(cfg.tradfi.universe)

    for ticker in db.get_mapped_tickers():
        if ticker and ticker != "NONE" and ticker not in candidates:
            candidates.append(ticker)

    return candidates


def _get_markets_to_analyze(db: Database) -> List[Dict[str, Any]]:
    """Return all non-duplicate Polymarket markets to evaluate."""
    markets = db.get_all_markets()
    return [m for m in markets if not m.get("is_duplicate")]


def _prepare_series(df: pd.DataFrame, value_column: str) -> Optional[pd.Series]:
    """Normalize time series DataFrame into a single datetime-indexed price series."""
    if df.empty or value_column not in df.columns:
        return None

    if "timestamp" in df.columns:
        df = df.copy()
        df["timestamp"] = pd.to_datetime(df["timestamp"], utc=True, errors="coerce")
        df = df.dropna(subset=["timestamp"])
        df = df.set_index("timestamp")
    elif df.index.name in ("timestamp", "Datetime", "DatetimeIndex"):
        df = df.copy()
    else:
        return None

    series = pd.to_numeric(df[value_column], errors="coerce").dropna()
    return series.sort_index()


def _build_lookback_window(days: int) -> Tuple[int, int]:
    now = datetime.now(timezone.utc)
    end_ts = int(now.timestamp())
    start_ts = int((now - timedelta(days=days)).timestamp())
    return start_ts, end_ts


def _fetch_market_series(
    pm_client: PolymarketClient,
    market_id: str,
    start_ts: int,
    end_ts: int,
) -> Optional[pd.Series]:
    tokens = pm_client.get_market_tokens(market_id)
    alpha_token = pm_client.pick_alpha_token(tokens)
    if not alpha_token:
        log.debug(f"No alpha token for market {market_id}")
        return None

    pm_df = pm_client.fetch_token_price_history(alpha_token, start_ts, end_ts)
    if pm_df.empty:
        log.debug(f"No PM data for market {market_id}")
        return None

    return _prepare_series(pm_df, "price")


def run_correlation_analysis(
    cfg: AppConfig,
    db: Database,
    output: Optional[str] = None,
    **kwargs,
) -> Dict[str, Any]:
    """
    Correlation analysis function:
    1. Fetch all mapped PM/TradFi pairs from DB
    2. Pull historical PM prices and TradFi closes
    3. Compute correlations + p-values (Pearson and optionally Spearman)
    4. Export to Excel with formatting
    5. Return stats dict

    Args:
        cfg: AppConfig
        db: Database
        output: Output file path (optional; defaults to exports/excel/correlation_results.xlsx)
        **kwargs: Additional arguments (unused)

    Returns:
        Dict with analysis stats: {
            "pairs_analyzed": int,
            "significant_pairs": int,
            "output_path": str,
            "correlation_data": List[Dict],
        }
    """
    log.info("=" * 60)
    log.info("CORRELATION ANALYSIS ENGINE")
    log.info("=" * 60)

    corr_cfg = cfg.correlation_config
    candidate_tickers = _get_candidate_tickers(cfg, db)
    markets = _get_markets_to_analyze(db)

    log.info(
        f"Starting correlation analysis for {len(markets)} markets "
        f"and {len(candidate_tickers)} TradFi tickers"
    )

    if not markets:
        log.warning("No markets found in database")
        return {
            "pairs_analyzed": 0,
            "significant_pairs": 0,
            "output_path": None,
            "status": "No data",
        }

    if not candidate_tickers:
        log.warning("No TradFi tickers configured for correlation analysis")
        return {
            "pairs_analyzed": 0,
            "significant_pairs": 0,
            "output_path": None,
            "status": "No data",
        }

    pm_client = PolymarketClient(cfg)
    tradfi_client = TradFiClient(cfg)

    correlation_data = []
    tf_cache: Dict[str, pd.Series] = {}

    # Prefetch TradFi close series for all candidate tickers
    for ticker in candidate_tickers:
        try:
            log.info(f"Fetching TradFi series for {ticker}")
            tf_df = tradfi_client.fetch_bars(ticker, lookback_days=corr_cfg.lookback_days)
            if tf_df.empty:
                log.warning(f"[{ticker}] No TradFi data available")
                continue

            tf_series = _prepare_series(tf_df, "close")
            if tf_series is None or tf_series.empty:
                log.warning(f"[{ticker}] Failed to normalize TradFi series")
                continue

            tf_cache[ticker] = tf_series
        except Exception as e:
            log.warning(f"Failed to fetch TradFi series for {ticker}: {e}")

    if not tf_cache:
        log.warning("No TradFi series available for any candidate tickers")
        return {
            "pairs_analyzed": 0,
            "significant_pairs": 0,
            "output_path": None,
            "status": "No TradFi data",
        }

    # Compute correlations for every market against every candidate ticker
    start_ts, end_ts = _build_lookback_window(corr_cfg.lookback_days)
    pairs_tested = 0

    for market in markets:
        mid = market.get("market_id")
        if not mid:
            continue

        matched_ticker = market.get("matched_ticker")
        market_title = market.get("question_text", "Unknown")

        try:
            pm_series = _fetch_market_series(pm_client, mid, start_ts, end_ts)
            if pm_series is None or pm_series.empty:
                continue

            for ticker, tf_close in tf_cache.items():
                pairs_tested += 1
                common_index = tf_close.index.intersection(pm_series.index)
                if len(common_index) < corr_cfg.min_overlap_points:
                    log.debug(
                        f"[{mid}] Insufficient overlap for {ticker}: {len(common_index)} points"
                    )
                    continue

                tf_aligned = tf_close.loc[common_index].values
                pm_aligned = pm_series.loc[common_index].values

                try:
                    pearson_corr, pearson_p = pearsonr(tf_aligned, pm_aligned)
                except Exception as err:
                    log.debug(f"[{mid}] Pearson failed for {ticker}: {err}")
                    continue

                spearman_corr = None
                spearman_p = None
                if corr_cfg.include_spearman:
                    try:
                        spearman_corr, spearman_p = spearmanr(tf_aligned, pm_aligned)
                    except Exception:
                        spearman_corr, spearman_p = None, None

                pearson_significant = (
                    pearson_p < corr_cfg.p_value_threshold
                    and abs(pearson_corr) >= corr_cfg.min_correlation_threshold
                )

                if not pearson_significant:
                    continue

                source = (
                    "mapped_ticker"
                    if matched_ticker and matched_ticker == ticker
                    else "tradfi_universe"
                )

                result = {
                    "ticker": ticker,
                    "market_id": mid,
                    "market_title": market_title,
                    "matched_ticker": matched_ticker,
                    "correlation_source": source,
                    "observations": len(common_index),
                    "pearson_correlation": round(pearson_corr, 4),
                    "pearson_pvalue": round(pearson_p, 6),
                    "pearson_significant": True,
                }

                if corr_cfg.include_spearman:
                    result["spearman_correlation"] = (
                        round(spearman_corr, 4) if spearman_corr is not None else None
                    )
                    result["spearman_pvalue"] = (
                        round(spearman_p, 6) if spearman_p is not None else None
                    )

                correlation_data.append(result)
                log.debug(
                    f"[{mid}] {ticker}: pearson_r={pearson_corr:.4f}, "
                    f"p={pearson_p:.6f}, source={source}"
                )

        except Exception as e:
            log.warning(f"[{mid}] Failed to process market {mid}: {e}")
            continue

    # Convert to DataFrame
    if not correlation_data:
        log.warning("No correlation data generated")
        return {
            "pairs_analyzed": 0,
            "significant_pairs": 0,
            "output_path": None,
            "status": "No data",
        }

    df_corr = pd.DataFrame(correlation_data)
    significant_count = (df_corr["pearson_significant"]).sum()

    # Determine output path
    if not output:
        root = find_project_root()
        output_dir = root / "exports" / "excel"
        output_dir.mkdir(parents=True, exist_ok=True)
        output = str(output_dir / "correlation_results.xlsx")
    else:
        output = str(output)
        Path(output).parent.mkdir(parents=True, exist_ok=True)

    # Export to Excel
    try:
        _export_correlation_excel(df_corr, output)
        log.info(f"Correlation results exported to {output}")
    except Exception as e:
        log.error(f"Failed to export Excel: {e}")
        output = None

    # Export to JSON if enabled
    json_path = None
    if corr_cfg.output_format in ["json", "both"]:
        json_path = output.replace(".xlsx", ".json") if output else None
        if json_path:
            try:
                with open(json_path, "w") as f:
                    json.dump(correlation_data, f, indent=2)
                log.info(f"JSON export saved to {json_path}")
            except Exception as e:
                log.warning(f"Failed to export JSON: {e}")

    stats = {
        "pairs_tested": pairs_tested,
        "pairs_analyzed": len(correlation_data),
        "significant_pairs": int(significant_count),
        "output_path": output,
        "json_path": json_path,
        "correlation_data": correlation_data,
        "status": "Complete",
    }

    log.info(
        f"Correlation analysis complete: {stats['pairs_analyzed']} pairs, "
        f"{stats['significant_pairs']} significant"
    )
    return stats


def _export_correlation_excel(df: pd.DataFrame, output_path: str):
    """Export correlation results to formatted Excel file."""
    with pd.ExcelWriter(output_path, engine="openpyxl") as writer:
        df.to_excel(writer, sheet_name="Correlations", index=False)

        # Format worksheet
        worksheet = writer.sheets["Correlations"]
        from openpyxl.styles import PatternFill, Font, Alignment, Border, Side
        from openpyxl.utils import get_column_letter

        # Color scheme: green for significant, gray for non-significant
        green_fill = PatternFill(start_color="C6EFCE", end_color="C6EFCE", fill_type="solid")
        gray_fill = PatternFill(start_color="F2F2F2", end_color="F2F2F2", fill_type="solid")
        header_fill = PatternFill(start_color="4472C4", end_color="4472C4", fill_type="solid")
        header_font = Font(color="FFFFFF", bold=True)
        thin_border = Border(
            left=Side(style="thin"),
            right=Side(style="thin"),
            top=Side(style="thin"),
            bottom=Side(style="thin"),
        )

        # Format header
        for col_num, col_title in enumerate(df.columns, 1):
            cell = worksheet.cell(row=1, column=col_num)
            cell.fill = header_fill
            cell.font = header_font
            cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)

        # Format data rows and auto-width columns
        for row_num in range(2, len(df) + 2):
            for col_num, col_title in enumerate(df.columns, 1):
                cell = worksheet.cell(row=row_num, column=col_num)
                cell.border = thin_border
                cell.alignment = Alignment(horizontal="center", vertical="center")

                # Conditional formatting: highlight significant correlations
                if "significant" in col_title.lower():
                    if cell.value is True:
                        cell.fill = green_fill
                    else:
                        cell.fill = gray_fill
                
                # Format numeric columns
                if "correlation" in col_title.lower() or "pvalue" in col_title.lower():
                    cell.number_format = "0.0000"

        # Auto-width columns
        for col_num, col_title in enumerate(df.columns, 1):
            max_length = len(col_title)
            for row in worksheet.iter_rows(min_col=col_num, max_col=col_num):
                for cell in row:
                    if isinstance(cell.value, (int, float)):
                        cell_length = len(str(round(cell.value, 4)))
                    else:
                        cell_length = len(str(cell.value)) if cell.value else 0
                    max_length = max(max_length, cell_length)
            worksheet.column_dimensions[get_column_letter(col_num)].width = min(max_length + 2, 50)
