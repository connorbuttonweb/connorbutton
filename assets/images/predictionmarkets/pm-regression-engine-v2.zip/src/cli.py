"""
cli.py — Command-line interface for the Polymarket → TradFi Regression Engine.

Usage:
    # New unified interface
    python -m src.cli run --function lasso --ticker SPY
    python -m src.cli run --function correlation --output results.xlsx
    python -m src.cli run --function regulatory-filter

    # Legacy commands (still supported)
    python -m src.cli init-db
    python -m src.cli run-phase --phase 1
    python -m src.cli run-pipeline --ticker SPY
    python -m src.cli run-pipeline-all --smoke-test
    python -m src.cli inspect --ticker SPY
    python -m src.cli summary
    python -m src.cli export-library
"""

import sys
from pathlib import Path

import click

from src.config_loader import AppConfig, load_config
from src.db import Database
from src.logging_utils import setup_logging, get_logger

log = get_logger("cli")


def _setup(config_path: str = None) -> tuple:
    """Load config, init logging, return (cfg, db)."""
    cfg = load_config(config_path)
    setup_logging(cfg.general.log_level, cfg.general.log_file)
    db = Database(cfg.general.db_path)
    return cfg, db


@click.group()
@click.option("--config", default=None, help="Path to config.yaml (default: auto-detect)")
@click.pass_context
def cli(ctx, config):
    """Polymarket → TradFi Prediction Market Regression Engine"""
    ctx.ensure_object(dict)
    ctx.obj["config_path"] = config


# ==================================================================
# NEW: Unified run command with function toggle
# ==================================================================
@cli.command("run")
@click.option(
    "--function",
    type=click.Choice(["lasso", "correlation", "regulatory-filter"]),
    default="lasso",
    help="Pipeline function to execute",
)
@click.option("--ticker", default=None, help="Specific ticker (for lasso mode)")
@click.option("--output", default=None, help="Output file path (for correlation/regulatory-filter)")
@click.option("--smoke-test", is_flag=True, help="Run in smoke-test mode (lasso only)")
@click.pass_context
def run(ctx, function, ticker, output, smoke_test):
    """
    Run the selected pipeline function.

    Functions:
      lasso               - LASSO regression with post-hoc OLS and Granger causality
      correlation         - Pearson/Spearman correlation analysis
      regulatory-filter   - Ontario/Canada regulatory plausibility assessment
    """
    cfg, db = _setup(ctx.obj.get("config_path"))
    db.init_schema()

    try:
        from src.engine_dispatcher import EngineDispatcher

        dispatcher = EngineDispatcher(cfg, db)
        result = dispatcher.execute(
            function=function,
            ticker=ticker,
            output=output,
            smoke_test=smoke_test,
        )

        click.echo(f"\n{'=' * 60}")
        click.echo(f"Function '{function}' completed successfully")
        click.echo(f"{'=' * 60}")

        # Pretty-print key stats
        for key, value in result.items():
            if key not in ["correlation_data"] and not isinstance(value, list):
                click.echo(f"{key:.<40} {value}")

    except Exception as e:
        click.echo(f"❌ Error: {e}", err=True)
        log.error(f"Pipeline failed: {e}", exc_info=True)
        sys.exit(1)


# ==================================================================
# LEGACY: init-db
# ==================================================================
@cli.command("init-db")
@click.pass_context
def init_db(ctx):
    """Create/update the SQLite database schema."""
    cfg, db = _setup(ctx.obj.get("config_path"))
    db.init_schema()
    click.echo(f"Database initialized at {cfg.general.db_path}")


# ==================================================================
# LEGACY: run-phase (Phases 1-6, backward compatible)
# ==================================================================
@cli.command("run-phase")
@click.option("--phase", type=int, required=True, help="Phase number (1-6)")
@click.option("--ticker", default=None, help="Ticker (for phases 3-6)")
@click.pass_context
def run_phase(ctx, phase, ticker):
    """Run a single pipeline phase. (Legacy command; use 'run --function lasso' instead)"""
    cfg, db = _setup(ctx.obj.get("config_path"))
    db.init_schema()

    from src.main import (
        phase1_discover_and_filter,
        phase2_map_and_dedup,
        phase3_ingest_data,
        phase4_transform,
        phase5_model,
        phase6_persist_and_export,
    )

    if phase == 1:
        stats = phase1_discover_and_filter(cfg, db)
        click.echo(f"Phase 1 complete: {stats}")

    elif phase == 2:
        stats = phase2_map_and_dedup(cfg, db)
        click.echo(f"Phase 2 complete: {stats}")

    elif phase == 3:
        data_store = phase3_ingest_data(cfg, db, ticker=ticker)
        click.echo(f"Phase 3 complete: {len(data_store)} tickers ingested")

    elif phase == 4:
        # Need phase 3 data first
        data_store = phase3_ingest_data(cfg, db, ticker=ticker)
        features_store = phase4_transform(data_store, cfg)
        click.echo(f"Phase 4 complete: {len(features_store)} tickers with features")

    elif phase == 5:
        # Need phases 3-4 data
        data_store = phase3_ingest_data(cfg, db, ticker=ticker)
        features_store = phase4_transform(data_store, cfg)
        run_results = phase5_model(features_store, cfg, db)
        click.echo(f"Phase 5 complete: {len(run_results)} ticker runs")

    elif phase == 6:
        # Need phases 3-5
        data_store = phase3_ingest_data(cfg, db, ticker=ticker)
        features_store = phase4_transform(data_store, cfg)
        run_results = phase5_model(features_store, cfg, db)
        stats = phase6_persist_and_export(run_results, cfg, db)
        click.echo(f"Phase 6 complete: {stats}")

    else:
        click.echo(f"Invalid phase: {phase}. Use 1-6.", err=True)
        sys.exit(1)


# ==================================================================
# LEGACY: run-pipeline (single ticker)
# ==================================================================
@cli.command("run-pipeline")
@click.option("--ticker", required=True, help="Ticker to process (e.g., SPY, BTC-USD)")
@click.pass_context
def run_pipeline(ctx, ticker):
    """Run the full pipeline for a single ticker (phases 3-6). (Legacy; use 'run --function lasso --ticker <TICKER>' instead)"""
    cfg, db = _setup(ctx.obj.get("config_path"))
    db.init_schema()

    from src.main import run_full_pipeline

    stats = run_full_pipeline(cfg, db, ticker=ticker)
    click.echo(f"Pipeline complete for {ticker}: {stats}")


# ==================================================================
# LEGACY: run-pipeline-all
# ==================================================================
@cli.command("run-pipeline-all")
@click.option("--smoke-test", is_flag=True, help="Run in smoke-test mode (limited scope)")
@click.pass_context
def run_pipeline_all(ctx, smoke_test):
    """Run the full pipeline for all mapped tickers. (Legacy; use 'run --function lasso' instead)"""
    cfg, db = _setup(ctx.obj.get("config_path"))
    db.init_schema()

    from src.main import run_full_pipeline

    stats = run_full_pipeline(cfg, db, smoke_test=smoke_test)
    click.echo(f"Full pipeline complete: {stats}")


# ==================================================================
# LEGACY: inspect
# ==================================================================
@cli.command("inspect")
@click.option("--ticker", required=True, help="Ticker to inspect")
@click.pass_context
def inspect_cmd(ctx, ticker):
    """Inspect a ticker's relationships and latest verification status."""
    cfg, db = _setup(ctx.obj.get("config_path"))
    db.init_schema()

    from src.diagnostics import inspect_ticker

    report = inspect_ticker(db, ticker)
    click.echo(report)


# ==================================================================
# LEGACY: summary
# ==================================================================
@cli.command("summary")
@click.pass_context
def summary_cmd(ctx):
    """Print a high-level summary of the database."""
    cfg, db = _setup(ctx.obj.get("config_path"))
    db.init_schema()

    from src.diagnostics import db_summary

    report = db_summary(db)
    click.echo(report)


# ==================================================================
# LEGACY: export-library
# ==================================================================
@cli.command("export-library")
@click.pass_context
def export_library(ctx):
    """Export the sentiment library to JSON and Excel."""
    cfg, db = _setup(ctx.obj.get("config_path"))
    db.init_schema()

    from src.library_export import export_json, export_excel
    from src.config_loader import find_project_root

    root = find_project_root()
    json_path = export_json(db, cfg, str(root / "exports" / "json"))
    excel_path = export_excel(db, cfg, str(root / "exports" / "excel"))

    click.echo(f"JSON export:  {json_path}")
    click.echo(f"Excel export: {excel_path}")


# ==================================================================
# Entry point
# ==================================================================
def main():
    cli()


if __name__ == "__main__":
    main()
