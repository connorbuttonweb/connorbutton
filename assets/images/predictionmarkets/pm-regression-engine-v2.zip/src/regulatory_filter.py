"""
regulatory_filter.py — Canadian/Ontario regulatory plausibility assessment.

Evaluates Polymarket markets for compliance and trading plausibility in
Canadian/Ontario regulatory context. Assigns risk scores and flags.
"""

from pathlib import Path
from typing import Dict, Any, List, Optional
import json
import re

import pandas as pd

from src.config_loader import AppConfig, find_project_root
from src.db import Database
from src.logging_utils import get_logger

log = get_logger("regulatory_filter")

# Ontario/Canada regulatory categories and keywords
RESTRICTED_ASSET_PATTERNS = {
    "securities_trading": [
        r"\b(?:stock|equity|share|IPO|insider trading|short selling)\b",
        r"\b(?:pump and dump|securities fraud)\b",
    ],
    "derivatives": [
        r"\b(?:option|futures|forward|swap|derivative)\b",
        r"\b(?:call|put)\s+(?:option|contract)",
    ],
    "leverage_margin": [
        r"\b(?:margin|leverage|short|short sale)\b",
        r"\b(?:leveraged|over-leveraged)\b",
    ],
    "credit_products": [
        r"\b(?:credit default swap|CDS|bond|credit spread)\b",
        r"\b(?:credit rating|downgrade|upgrade)\b",
    ],
    "crypto_high_risk": [
        r"\b(?:shitcoin|meme coin|penny crypto)\b",
        r"\b(?:rug pull|scam coin)\b",
    ],
}

REGULATORY_TRIGGER_KEYWORDS = [
    "margin",
    "leverage",
    "short",
    "options",
    "derivatives",
    "swap",
    "credit default",
    "risky",
    "speculative",
    "insider",
    "fraud",
]

FAVORABLE_CATEGORIES = [
    "macro",
    "economic",
    "inflation",
    "recession",
    "crypto",
    "bitcoin",
    "ethereum",
    "commodity",
    "oil",
    "gold",
]

ONTARIO_RELEVANT_KEYWORDS = [
    "canada",
    "canadian",
    "ontario",
    "toronto",
    "ftse",
    "tsx",
    "boc",
    "bank of canada",
    "cdx",
    "cad",
    "canadian dollar",
]


def run_regulatory_filter(
    cfg: AppConfig,
    db: Database,
    output: Optional[str] = None,
    **kwargs,
) -> Dict[str, Any]:
    """
    Regulatory plausibility filter for Canadian/Ontario context:
    1. Fetch all Polymarket markets from DB
    2. Classify and assess regulatory plausibility
    3. Assign risk scores (0-100, higher = riskier)
    4. Export detailed assessment to Excel
    5. Return stats dict

    Args:
        cfg: AppConfig
        db: Database
        output: Output file path (optional; defaults to exports/excel/regulatory_assessment.xlsx)
        **kwargs: Additional arguments (unused)

    Returns:
        Dict with regulatory assessment stats
    """
    log.info("=" * 60)
    log.info("REGULATORY PLAUSIBILITY FILTER (Ontario/Canada)")
    log.info("=" * 60)

    reg_cfg = cfg.regulatory_filter_config
    all_markets = db.get_all_markets()
    log.info(f"Assessing {len(all_markets)} markets for Ontario regulatory context")

    if not all_markets:
        log.warning("No markets found in database")
        return {
            "markets_assessed": 0,
            "compliant_markets": 0,
            "flagged_markets": 0,
            "output_path": None,
            "status": "No data",
        }

    assessment_data = []

    for market in all_markets:
        title = market.get("question_text", "").lower()
        tags = json.loads(market.get("tags", "[]")) if market.get("tags") else []
        volume = market.get("volume_24h", 0)
        market_id = market.get("market_id", "unknown")

        # Assess market
        assessment = _assess_market_plausibility(
            title, tags, volume, market_id, reg_cfg
        )
        assessment_data.append(assessment)

        log.debug(
            f"[{market_id}] Plausibility: {assessment['plausibility_score']:.0f}%, "
            f"Risk: {assessment['risk_level']}"
        )

    # Convert to DataFrame
    df_assess = pd.DataFrame(assessment_data)

    compliant = (df_assess["plausibility_score"] >= 60).sum()
    flagged = (df_assess["risk_level"].isin(["HIGH", "CRITICAL"])).sum()

    # Determine output path
    if not output:
        root = find_project_root()
        output_dir = root / "exports" / "excel"
        output_dir.mkdir(parents=True, exist_ok=True)
        output = str(output_dir / "regulatory_assessment.xlsx")
    else:
        output = str(output)
        Path(output).parent.mkdir(parents=True, exist_ok=True)

    # Export to Excel
    try:
        _export_regulatory_excel(df_assess, output)
        log.info(f"Regulatory assessment exported to {output}")
    except Exception as e:
        log.error(f"Failed to export Excel: {e}")
        output = None

    # Export to JSON if enabled
    json_path = None
    if reg_cfg.output_format in ["json", "both"]:
        json_path = output.replace(".xlsx", ".json") if output else None
        if json_path:
            try:
                with open(json_path, "w") as f:
                    json.dump(assessment_data, f, indent=2)
                log.info(f"JSON export saved to {json_path}")
            except Exception as e:
                log.warning(f"Failed to export JSON: {e}")

    stats = {
        "markets_assessed": len(assessment_data),
        "compliant_markets": int(compliant),
        "flagged_markets": int(flagged),
        "average_plausibility": round(df_assess["plausibility_score"].mean(), 1),
        "output_path": output,
        "json_path": json_path,
        "status": "Complete",
    }

    log.info(
        f"Regulatory assessment complete: {stats['markets_assessed']} markets, "
        f"{stats['compliant_markets']} compliant, {stats['flagged_markets']} flagged"
    )
    return stats


def _assess_market_plausibility(
    title: str,
    tags: List[str],
    volume: float,
    market_id: str,
    cfg: Dict,
) -> Dict[str, Any]:
    """
    Assess a single market's plausibility and risk profile.

    Returns assessment dict with scores and flags.
    """
    assessment = {
        "market_id": market_id,
        "title": title,
        "volume_24h": volume,
        "categories_found": [],
        "regulatory_triggers": [],
        "ontario_relevance": _score_ontario_relevance(title, tags),
        "category_score": 0,
        "volume_score": 0,
        "risk_flags": [],
        "plausibility_score": 0,
        "risk_level": "UNKNOWN",
    }

    # Category assessment
    category_score = _assess_category(title, tags, assessment)

    # Volume credibility
    volume_score = _score_volume_credibility(volume)

    # Ontario relevance
    ontario_score = assessment["ontario_relevance"]

    # Regulatory triggers
    triggers = _identify_regulatory_triggers(title)
    assessment["regulatory_triggers"] = triggers
    risk_penalty = len(triggers) * 10  # Each trigger reduces score by 10

    # Overall plausibility
    weights = cfg.get("score_weights", {
        "category_match": 0.4,
        "jurisdiction_relevance": 0.3,
        "volume_credibility": 0.2,
        "regulatory_risk": 0.1,
    })

    # Normalize scores to 0-100
    category_score = min(100, max(0, category_score))
    volume_score = min(100, max(0, volume_score))
    ontario_score = min(100, max(0, ontario_score))
    risk_penalty = min(100, max(0, risk_penalty))

    plausibility = (
        weights["category_match"] * category_score
        + weights["jurisdiction_relevance"] * ontario_score
        + weights["volume_credibility"] * volume_score
        + weights["regulatory_risk"] * (100 - risk_penalty)
    )

    assessment["category_score"] = round(category_score, 1)
    assessment["volume_score"] = round(volume_score, 1)
    assessment["plausibility_score"] = round(plausibility, 1)

    # Determine risk level
    if len(assessment["regulatory_triggers"]) >= 3 or risk_penalty > 50:
        assessment["risk_level"] = "CRITICAL"
    elif len(assessment["regulatory_triggers"]) >= 2 or risk_penalty > 30:
        assessment["risk_level"] = "HIGH"
    elif len(assessment["regulatory_triggers"]) >= 1 or risk_penalty > 10:
        assessment["risk_level"] = "MEDIUM"
    else:
        assessment["risk_level"] = "LOW"

    return assessment


def _assess_category(title: str, tags: List[str], assessment: Dict) -> float:
    """Assess market category favorability. Higher is better."""
    score = 50  # Base score

    combined_text = (title + " " + " ".join(tags)).lower()

    # Check restricted categories
    for category, patterns in RESTRICTED_ASSET_PATTERNS.items():
        for pattern in patterns:
            if re.search(pattern, combined_text, re.IGNORECASE):
                assessment["categories_found"].append(category)
                score -= 20
                assessment["risk_flags"].append(f"Restricted category: {category}")
                break

    # Check favorable categories
    for fav_category in FAVORABLE_CATEGORIES:
        if fav_category in combined_text:
            score += 15
            assessment["categories_found"].append(fav_category)
            break

    return score


def _score_ontario_relevance(title: str, tags: List[str]) -> float:
    """Score market relevance to Ontario/Canada. 0-100."""
    combined_text = (title + " " + " ".join(tags)).lower()
    score = 30  # Base score for non-Canadian markets (still tradeable)

    # Exact matches boost relevance
    for keyword in ONTARIO_RELEVANT_KEYWORDS:
        if keyword.lower() in combined_text:
            score += 20

    return min(100, score)


def _score_volume_credibility(volume: float) -> float:
    """Score volume as proxy for market credibility. 0-100."""
    if volume < 100:
        return 20  # Very low volume = low credibility
    elif volume < 500:
        return 40
    elif volume < 2000:
        return 60
    elif volume < 10000:
        return 80
    else:
        return 100


def _identify_regulatory_triggers(title: str) -> List[str]:
    """Identify regulatory risk keywords in market title."""
    triggers = []
    for keyword in REGULATORY_TRIGGER_KEYWORDS:
        if keyword.lower() in title.lower():
            triggers.append(keyword)
    return triggers


def _export_regulatory_excel(df: pd.DataFrame, output_path: str):
    """Export regulatory assessment to formatted Excel file."""
    with pd.ExcelWriter(output_path, engine="openpyxl") as writer:
        df.to_excel(writer, sheet_name="Assessment", index=False)

        # Format worksheet
        worksheet = writer.sheets["Assessment"]
        from openpyxl.styles import PatternFill, Font, Alignment, Border, Side
        from openpyxl.utils import get_column_letter

        # Color scheme by risk level
        risk_colors = {
            "CRITICAL": "FF6B6B",
            "HIGH": "FFA500",
            "MEDIUM": "FFD93D",
            "LOW": "6BCB77",
        }

        header_fill = PatternFill(start_color="2C3E50", end_color="2C3E50", fill_type="solid")
        header_font = Font(color="FFFFFF", bold=True)
        thin_border = Border(
            left=Side(style="thin"),
            right=Side(style="thin"),
            top=Side(style="thin"),
            bottom=Side(style="thin"),
        )

        # Format header
        for col_num, col_title in enumerate(df.columns, 1):
            cell = worksheet.cell(row=1, column=col_num)
            cell.fill = header_fill
            cell.font = header_font
            cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)

        # Format data rows
        for row_num in range(2, len(df) + 2):
            for col_num, col_title in enumerate(df.columns, 1):
                cell = worksheet.cell(row=row_num, column=col_num)
                cell.border = thin_border
                cell.alignment = Alignment(horizontal="left", vertical="top", wrap_text=True)

                # Conditional formatting by risk level
                if col_title == "risk_level":
                    risk_value = cell.value
                    if risk_value in risk_colors:
                        cell.fill = PatternFill(
                            start_color=risk_colors[risk_value],
                            end_color=risk_colors[risk_value],
                            fill_type="solid",
                        )

                # Format numeric columns
                if "score" in col_title.lower() or "volume" in col_title.lower():
                    if isinstance(cell.value, (int, float)):
                        cell.number_format = "0.0"
                        cell.alignment = Alignment(horizontal="center", vertical="center")

        # Auto-width columns
        for col_num, col_title in enumerate(df.columns, 1):
            max_length = len(col_title)
            for row in worksheet.iter_rows(min_col=col_num, max_col=col_num):
                for cell in row:
                    if isinstance(cell.value, (int, float)):
                        cell_length = len(str(round(cell.value, 1)))
                    else:
                        cell_length = len(str(cell.value)) if cell.value else 0
                    max_length = max(max_length, cell_length)
            worksheet.column_dimensions[get_column_letter(col_num)].width = min(max_length + 2, 60)

        # Freeze header row
        worksheet.freeze_panes = "A2"
