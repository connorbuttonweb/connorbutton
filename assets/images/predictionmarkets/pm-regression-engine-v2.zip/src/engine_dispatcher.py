"""
engine_dispatcher.py — Routes execution to the correct pipeline function.

Supports multiple modes:
  - lasso: LASSO regression with post-hoc OLS and Granger causality
  - correlation: Pearson/Spearman correlation analysis
  - regulatory-filter: Canadian/Ontario regulatory plausibility assessment
"""

from enum import Enum
from typing import Dict, Any, Optional

from src.config_loader import AppConfig
from src.db import Database
from src.logging_utils import get_logger

log = get_logger("dispatcher")


class FunctionMode(Enum):
    """Available pipeline functions."""
    LASSO = "lasso"
    CORRELATION = "correlation"
    REGULATORY_FILTER = "regulatory-filter"


class EngineDispatcher:
    """Routes pipeline execution based on selected function."""

    def __init__(self, cfg: AppConfig, db: Database):
        self.cfg = cfg
        self.db = db

    def execute(
        self,
        function: str,
        ticker: Optional[str] = None,
        output: Optional[str] = None,
        smoke_test: bool = False,
        **kwargs,
    ) -> Dict[str, Any]:
        """
        Execute the selected pipeline function.

        Args:
            function: Function name (lasso, correlation, regulatory-filter)
            ticker: Optional ticker for single-ticker runs (lasso mode)
            output: Optional output file path (correlation, regulatory-filter)
            smoke_test: Run in limited-scope mode
            **kwargs: Additional passthrough arguments

        Returns:
            Dict with execution stats and results
        """
        try:
            mode = FunctionMode(function)
        except ValueError:
            available = ", ".join([m.value for m in FunctionMode])
            raise ValueError(
                f"Unknown function: {function}. Available: {available}"
            )

        log.info(f"Engine dispatcher: executing function '{function}'")

        if mode == FunctionMode.LASSO:
            from src.main import run_lasso_pipeline
            return run_lasso_pipeline(
                self.cfg, self.db, ticker=ticker, smoke_test=smoke_test, **kwargs
            )

        elif mode == FunctionMode.CORRELATION:
            from src.correlation_engine import run_correlation_analysis
            return run_correlation_analysis(
                self.cfg, self.db, output=output, **kwargs
            )

        elif mode == FunctionMode.REGULATORY_FILTER:
            from src.regulatory_filter import run_regulatory_filter
            return run_regulatory_filter(
                self.cfg, self.db, output=output, **kwargs
            )

        else:
            raise RuntimeError(f"Unhandled function mode: {mode}")
