"""
config_loader.py — Load and validate config.yaml + .env
"""

import os
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional

import yaml
from dotenv import load_dotenv
from pydantic import BaseModel, Field


# ---------------------------------------------------------------------------
# Pydantic config models
# ---------------------------------------------------------------------------

class GeneralConfig(BaseModel):
    db_path: str = "db/pm_sentiment_engine.db"
    log_level: str = "INFO"
    log_file: str = "logs/engine.log"
    timezone: str = "UTC"
    debug_save_intermediates: bool = False


class PolymarketConfig(BaseModel):
    gamma_base_url: str = "https://gamma-api.polymarket.com"
    clob_base_url: str = "https://clob.polymarket.com"
    user_agent: str = "Mozilla/5.0 (ResearchEngine/1.0)"
    max_markets_per_run: int = 2000
    page_size: int = 100
    request_delay_seconds: float = 0.25


class FiltersConfig(BaseModel):
    excluded_tags: List[str] = Field(default_factory=list)
    excluded_keywords_regex: List[str] = Field(default_factory=list)
    include_keywords_regex: List[str] = Field(default_factory=list)
    min_24h_volume_absolute: float = 500.0
    dynamic_volume_share_threshold: float = 0.001


class LLMConfig(BaseModel):
    provider: str = "openai"
    model_name: str = "gpt-4o-mini"
    max_tokens: int = 4096
    temperature: float = 0.0
    batch_size: int = 10
    max_markets_per_llm_run: int = 200
    enabled: bool = True
    dry_run: bool = False
    cache_dir: str = "data/debug/llm_cache"


class EmbeddingsConfig(BaseModel):
    enabled: bool = True
    model_name: str = "all-MiniLM-L6-v2"
    similarity_threshold: float = 0.92


class TradFiConfig(BaseModel):
    source: str = "yfinance"
    bar_interval_minutes: int = 5
    lookback_days: int = 14
    min_effective_observations: int = 500
    universe: List[str] = Field(default_factory=list)


class TransformConfig(BaseModel):
    logit_clip_epsilon: float = 1e-6
    max_merge_gap_minutes: int = 5
    drop_zero_trade_bins: bool = True
    add_market_open_dummy: bool = True
    add_hour_of_day_dummies: bool = True
    add_day_of_week_dummies: bool = True


class StationarityConfig(BaseModel):
    adf_p_threshold: float = 0.05
    kpss_p_threshold: float = 0.05
    fallback_strategy: str = "difference"


class ModelingConfig(BaseModel):
    model_type: str = "lasso"
    cv_splits: int = 5
    cv_gap: int = 1
    max_lags_returns: int = 3
    max_lags_pm: int = 3
    alpha_range_min: float = 0.0001
    alpha_range_max: float = 1.0
    n_alphas: int = 50


class VerificationConfig(BaseModel):
    candidate_p_value_max: float = 0.10
    verified_p_value_max: float = 0.05
    verified_granger_p_max: float = 0.05
    min_oos_ic_for_verified: float = 0.05
    min_oos_sharpe_for_verified: float = 0.5
    min_effective_obs_for_verified: int = 500
    decay_threshold_days: int = 30


class CorrelationConfig(BaseModel):
    min_correlation_threshold: float = 0.3
    p_value_threshold: float = 0.05
    lookback_days: int = 14
    output_format: str = "excel"
    include_spearman: bool = True
    min_overlap_points: int = 50


class RegulatoryFilterConfig(BaseModel):
    jurisdiction: str = "ontario"
    risk_assessment_level: str = "standard"
    output_format: str = "excel"
    restricted_categories: List[str] = Field(default_factory=list)
    regulatory_trigger_keywords: List[str] = Field(default_factory=list)
    score_weights: Dict[str, float] = Field(default_factory=lambda: {
        "category_match": 0.4,
        "jurisdiction_relevance": 0.3,
        "volume_credibility": 0.2,
        "regulatory_risk": 0.1,
    })


class ExportsConfig(BaseModel):
    json_verified_only: bool = True
    excel_conditional_formatting: bool = True


class AppConfig(BaseModel):
    general: GeneralConfig = GeneralConfig()
    polymarket: PolymarketConfig = PolymarketConfig()
    filters: FiltersConfig = FiltersConfig()
    llm: LLMConfig = LLMConfig()
    embeddings: EmbeddingsConfig = EmbeddingsConfig()
    tradfi: TradFiConfig = TradFiConfig()
    transform: TransformConfig = TransformConfig()
    stationarity: StationarityConfig = StationarityConfig()
    modeling: ModelingConfig = ModelingConfig()
    verification: VerificationConfig = VerificationConfig()
    correlation_config: CorrelationConfig = CorrelationConfig()
    regulatory_filter_config: RegulatoryFilterConfig = RegulatoryFilterConfig()
    exports: ExportsConfig = ExportsConfig()


# ---------------------------------------------------------------------------
# Loading helpers
# ---------------------------------------------------------------------------

_PROJECT_ROOT: Optional[Path] = None


def find_project_root() -> Path:
    """Walk up from this file to find config.yaml."""
    global _PROJECT_ROOT
    if _PROJECT_ROOT is not None:
        return _PROJECT_ROOT
    candidate = Path(__file__).resolve().parent.parent
    if (candidate / "config.yaml").exists():
        _PROJECT_ROOT = candidate
        return _PROJECT_ROOT
    # fallback: cwd
    candidate = Path.cwd()
    if (candidate / "config.yaml").exists():
        _PROJECT_ROOT = candidate
        return _PROJECT_ROOT
    raise FileNotFoundError(
        "Cannot locate config.yaml. Run from the project root directory."
    )


def load_config(config_path: Optional[str] = None) -> AppConfig:
    """Load config.yaml and .env, return validated AppConfig."""
    root = find_project_root()

    # Load .env
    env_path = root / ".env"
    if env_path.exists():
        load_dotenv(env_path)

    # Load YAML
    yaml_path = Path(config_path) if config_path else root / "config.yaml"
    if not yaml_path.exists():
        print(f"[WARN] config.yaml not found at {yaml_path}, using defaults")
        return AppConfig()

    with open(yaml_path, "r") as f:
        raw: Dict[str, Any] = yaml.safe_load(f) or {}

    cfg = AppConfig(**raw)

    # Ensure dirs exist
    for d in [
        root / "data" / "raw",
        root / "data" / "processed",
        root / "data" / "debug",
        root / "data" / "debug" / "llm_cache",
        root / "db",
        root / "exports" / "json",
        root / "exports" / "excel",
        root / "logs",
    ]:
        d.mkdir(parents=True, exist_ok=True)

    return cfg


def get_openai_key() -> Optional[str]:
    """Return OPENAI_API_KEY from env or None."""
    return os.environ.get("OPENAI_API_KEY")
