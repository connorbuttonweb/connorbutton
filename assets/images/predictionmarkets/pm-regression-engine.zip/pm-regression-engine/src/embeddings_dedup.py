"""
embeddings_dedup.py — Sentence-embedding-based deduplication of Polymarket questions.
Reduces the number of markets sent to the LLM.
"""

from typing import Any, Dict, List, Tuple

import numpy as np

from src.config_loader import AppConfig
from src.logging_utils import get_logger

log = get_logger("embeddings")


class EmbeddingDeduplicator:
    """
    Use sentence-transformers to group near-duplicate market questions.
    Within each group the highest-volume market is the "primary";
    others are marked as candidate duplicates.
    """

    def __init__(self, cfg: AppConfig):
        self.cfg = cfg
        self.threshold = cfg.embeddings.similarity_threshold
        self.model = None  # lazy load

    def _load_model(self):
        if self.model is not None:
            return
        try:
            from sentence_transformers import SentenceTransformer
            log.info(f"Loading embedding model: {self.cfg.embeddings.model_name}")
            self.model = SentenceTransformer(self.cfg.embeddings.model_name)
        except ImportError:
            log.error(
                "sentence-transformers not installed; "
                "set embeddings.enabled=false in config.yaml"
            )
            raise

    def deduplicate(
        self, markets: List[Dict[str, Any]]
    ) -> Tuple[List[Dict[str, Any]], List[str]]:
        """
        Return (primaries, duplicate_ids).
        - primaries: markets to send to LLM (one per cluster).
        - duplicate_ids: market_ids that are near-duplicates of a primary.
        """
        if not markets:
            return [], []

        if not self.cfg.embeddings.enabled:
            log.info("Embedding dedup disabled")
            return markets, []

        self._load_model()

        questions = [m.get("question_text", "") for m in markets]
        log.info(f"Computing embeddings for {len(questions)} markets…")
        embeddings = self.model.encode(questions, show_progress_bar=False)
        embeddings = np.array(embeddings)

        # Normalize for cosine similarity
        norms = np.linalg.norm(embeddings, axis=1, keepdims=True)
        norms = np.where(norms == 0, 1, norms)
        normed = embeddings / norms

        # Greedy clustering
        n = len(markets)
        assigned = [False] * n
        clusters: List[List[int]] = []

        for i in range(n):
            if assigned[i]:
                continue
            cluster = [i]
            assigned[i] = True
            for j in range(i + 1, n):
                if assigned[j]:
                    continue
                sim = float(np.dot(normed[i], normed[j]))
                if sim >= self.threshold:
                    cluster.append(j)
                    assigned[j] = True
            clusters.append(cluster)

        # Pick primary (highest volume) in each cluster
        primaries = []
        duplicate_ids = []

        for cluster in clusters:
            # Sort by volume descending
            cluster_markets = [(idx, markets[idx]) for idx in cluster]
            cluster_markets.sort(
                key=lambda x: x[1].get("volume_24h", 0.0), reverse=True
            )
            # First is primary
            primaries.append(cluster_markets[0][1])
            # Rest are duplicates
            for _, m in cluster_markets[1:]:
                duplicate_ids.append(m["market_id"])

        log.info(
            f"Embedding dedup: {n} markets → {len(primaries)} primaries, "
            f"{len(duplicate_ids)} duplicates (threshold={self.threshold})"
        )

        return primaries, duplicate_ids
