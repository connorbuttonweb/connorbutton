# Polymarket → TradFi Prediction Market Regression Engine
__version__ = "0.1.0"
