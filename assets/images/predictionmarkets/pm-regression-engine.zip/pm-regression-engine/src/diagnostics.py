"""
diagnostics.py — Debug utilities: inspect ticker status, dump tables, sanity checks.
"""

import json
from typing import Optional

import pandas as pd

from src.config_loader import AppConfig
from src.db import Database
from src.logging_utils import get_logger

log = get_logger("diagnostics")


def inspect_ticker(db: Database, ticker: str) -> str:
    """
    Print a human-readable report for a ticker:
    - Mapped markets
    - Latest run status and key metrics
    - Historical runs
    """
    lines = [f"=== Diagnostic Report: {ticker} ===\n"]

    # Markets
    markets = db.get_markets_for_ticker(ticker)
    lines.append(f"Mapped markets ({len(markets)}):")
    for m in markets:
        lines.append(
            f"  - {m['market_id'][:16]}… : {m.get('question_text', '')[:80]}"
        )
    lines.append("")

    # Latest run
    latest = db.get_latest_run(ticker)
    if latest:
        lines.append("Latest run:")
        lines.append(f"  Run ID:    {latest['run_id']}")
        lines.append(f"  Timestamp: {latest['run_timestamp']}")
        lines.append(f"  Status:    {latest['status']}")
        lines.append(f"  Adj R²:    {latest.get('adj_r2')}")
        lines.append(f"  Granger p: {latest.get('granger_p')}")
        lines.append(f"  OOS IC:    {latest.get('oos_ic')}")
        lines.append(f"  OOS Sharpe:{latest.get('oos_sharpe')}")
        lines.append(f"  Num obs:   {latest.get('num_obs')}")

        # Betas
        betas_raw = latest.get("betas", "{}")
        if isinstance(betas_raw, str):
            try:
                betas = json.loads(betas_raw)
            except Exception:
                betas = {}
        else:
            betas = betas_raw

        if betas:
            lines.append("  Betas:")
            for feat, val in sorted(betas.items(), key=lambda x: abs(x[1] or 0), reverse=True):
                lines.append(f"    {feat}: {val:.6f}" if isinstance(val, float) else f"    {feat}: {val}")
    else:
        lines.append("No runs found for this ticker.")

    lines.append("")

    # All runs
    conn = db.connect()
    rows = conn.execute(
        "SELECT run_id, run_timestamp, status, adj_r2, oos_ic, oos_sharpe "
        "FROM pm_sentiment_library WHERE ticker = ? ORDER BY run_timestamp DESC",
        (ticker,),
    ).fetchall()
    if rows:
        lines.append(f"All runs ({len(rows)}):")
        for r in rows:
            lines.append(
                f"  {r['run_timestamp']} | {r['status']:10s} | "
                f"R²={r['adj_r2']!s:>8s} | IC={r['oos_ic']!s:>8s}"
            )

    report = "\n".join(lines)
    return report


def db_summary(db: Database) -> str:
    """Print a high-level summary of the database."""
    lines = ["=== Database Summary ===\n"]
    lines.append(f"Total markets:  {db.count_markets()}")
    lines.append(f"Total runs:     {db.count_runs()}")

    conn = db.connect()

    # Status distribution
    rows = conn.execute(
        "SELECT status, COUNT(*) as cnt FROM pm_sentiment_library GROUP BY status"
    ).fetchall()
    lines.append("\nRuns by status:")
    for r in rows:
        lines.append(f"  {r['status']:10s}: {r['cnt']}")

    # Mapped tickers
    tickers = db.get_mapped_tickers()
    lines.append(f"\nMapped tickers ({len(tickers)}):")
    for t in tickers[:20]:
        lines.append(f"  {t}")
    if len(tickers) > 20:
        lines.append(f"  … and {len(tickers) - 20} more")

    return "\n".join(lines)


def sanity_check_dataframe(
    df: pd.DataFrame,
    target_col: str,
    min_obs: int,
    label: str = "",
) -> bool:
    """
    Run sanity checks on a features DataFrame before modeling.
    Returns True if all checks pass.
    """
    ok = True
    prefix = f"[{label}] " if label else ""

    # Check min observations
    if len(df) < min_obs:
        log.warning(f"{prefix}Only {len(df)} rows (need {min_obs})")
        ok = False

    # Check target exists and has no NaNs
    if target_col not in df.columns:
        log.warning(f"{prefix}Target column '{target_col}' missing")
        return False

    nan_count = df[target_col].isna().sum()
    if nan_count > 0:
        log.warning(f"{prefix}Target has {nan_count} NaN values")
        ok = False

    # Check for all-zero feature columns
    numeric_cols = df.select_dtypes(include=["number"]).columns
    for c in numeric_cols:
        if c == target_col:
            continue
        if (df[c] == 0).all():
            log.warning(f"{prefix}Column '{c}' is all zeros")

    # Check for infinite values
    inf_count = df[numeric_cols].apply(lambda x: (~x.isfinite()).sum() if hasattr(x, 'isfinite') else 0).sum()

    if ok:
        log.debug(f"{prefix}Sanity checks passed ({len(df)} rows)")

    return ok
