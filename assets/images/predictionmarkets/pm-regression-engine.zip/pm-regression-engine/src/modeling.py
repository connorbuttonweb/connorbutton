"""
modeling.py — LASSO/ElasticNet pipeline with time-series CV, post-LASSO OLS,
Granger causality, and walk-forward OOS validation.
"""

import json
import uuid
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Tuple

import numpy as np
import pandas as pd
from sklearn.linear_model import ElasticNet, Lasso, LassoCV, ElasticNetCV
from sklearn.model_selection import TimeSeriesSplit
from sklearn.preprocessing import StandardScaler
import statsmodels.api as sm
from statsmodels.regression.linear_model import OLS
from statsmodels.tsa.stattools import grangercausalitytests

from src.config_loader import AppConfig
from src.logging_utils import get_logger

log = get_logger("modeling")


# ---------------------------------------------------------------------------
# Helper: identify feature columns
# ---------------------------------------------------------------------------

def _feature_columns(df: pd.DataFrame, target_col: str) -> List[str]:
    """Return all numeric columns except the target and metadata columns."""
    skip = {target_col, "timestamp", "tradfi_close", "tradfi_volume"}
    return [
        c for c in df.select_dtypes(include=[np.number]).columns
        if c not in skip
    ]


# ---------------------------------------------------------------------------
# LASSO / ElasticNet with TimeSeriesSplit
# ---------------------------------------------------------------------------

def fit_lasso_cv(
    X: np.ndarray,
    y: np.ndarray,
    cfg: AppConfig,
    feature_names: List[str],
) -> Tuple[Optional[object], np.ndarray, float]:
    """
    Fit LASSO or ElasticNet with TimeSeriesSplit cross-validation.
    Returns (fitted_model, coefficients, best_alpha).
    """
    tscv = TimeSeriesSplit(
        n_splits=cfg.modeling.cv_splits,
        gap=cfg.modeling.cv_gap,
    )

    alphas = np.logspace(
        np.log10(cfg.modeling.alpha_range_min),
        np.log10(cfg.modeling.alpha_range_max),
        cfg.modeling.n_alphas,
    )

    if cfg.modeling.model_type == "elasticnet":
        model = ElasticNetCV(
            l1_ratio=0.5,
            alphas=alphas,
            cv=tscv,
            max_iter=10000,
            n_jobs=-1,
        )
    else:
        model = LassoCV(
            alphas=alphas,
            cv=tscv,
            max_iter=10000,
            n_jobs=-1,
        )

    try:
        model.fit(X, y)
    except Exception as e:
        log.error(f"LASSO CV fit failed: {e}")
        return None, np.array([]), 0.0

    coefs = model.coef_
    alpha = model.alpha_

    n_nonzero = np.count_nonzero(coefs)
    log.info(
        f"LASSO CV: best alpha={alpha:.6f}, "
        f"{n_nonzero}/{len(coefs)} non-zero coefficients"
    )

    return model, coefs, alpha


# ---------------------------------------------------------------------------
# Post-LASSO OLS with HAC errors
# ---------------------------------------------------------------------------

def post_lasso_ols(
    X: np.ndarray,
    y: np.ndarray,
    coefs: np.ndarray,
    feature_names: List[str],
) -> Dict[str, Any]:
    """
    Refit OLS on features with non-zero LASSO coefficients.
    Uses Newey-West HAC standard errors.

    Returns dict with:
      betas, std_errors, t_stats, p_values, adj_r2,
      significant_features, n_obs
    """
    nonzero_mask = coefs != 0
    selected_features = [f for f, nz in zip(feature_names, nonzero_mask) if nz]

    if not selected_features:
        log.info("No non-zero features from LASSO — Null result")
        return {
            "betas": {},
            "std_errors": {},
            "t_stats": {},
            "p_values": {},
            "adj_r2": None,
            "significant_features": [],
            "n_obs": len(y),
        }

    selected_idx = [i for i, nz in enumerate(nonzero_mask) if nz]
    X_sel = X[:, selected_idx]
    X_sel_const = sm.add_constant(X_sel)

    try:
        ols_model = OLS(y, X_sel_const).fit(
            cov_type="HAC",
            cov_kwds={"maxlags": max(1, int(len(y) ** (1 / 3)))},
        )
    except Exception as e:
        log.error(f"Post-LASSO OLS failed: {e}")
        return {
            "betas": {},
            "std_errors": {},
            "t_stats": {},
            "p_values": {},
            "adj_r2": None,
            "significant_features": selected_features,
            "n_obs": len(y),
        }

    # Map results (skip constant at index 0)
    betas = {}
    std_errors = {}
    t_stats = {}
    p_values = {}

    params = ols_model.params[1:]  # skip constant
    bse = ols_model.bse[1:]
    tvals = ols_model.tvalues[1:]
    pvals = ols_model.pvalues[1:]

    for i, feat in enumerate(selected_features):
        betas[feat] = float(params[i]) if i < len(params) else None
        std_errors[feat] = float(bse[i]) if i < len(bse) else None
        t_stats[feat] = float(tvals[i]) if i < len(tvals) else None
        p_values[feat] = float(pvals[i]) if i < len(pvals) else None

    adj_r2 = float(ols_model.rsquared_adj) if ols_model.rsquared_adj is not None else None

    log.info(
        f"Post-LASSO OLS: {len(selected_features)} features, "
        f"adj R²={adj_r2:.6f}" if adj_r2 else "adj R²=N/A"
    )

    return {
        "betas": betas,
        "std_errors": std_errors,
        "t_stats": t_stats,
        "p_values": p_values,
        "adj_r2": adj_r2,
        "significant_features": selected_features,
        "n_obs": len(y),
    }


# ---------------------------------------------------------------------------
# Granger causality
# ---------------------------------------------------------------------------

def granger_test(
    df: pd.DataFrame,
    target_col: str,
    feature_cols: List[str],
    max_lags: int = 3,
) -> float:
    """
    Run Granger causality tests for each feature against the target.
    Returns the minimum p-value across all features and lags.
    """
    min_p = 1.0

    for feat in feature_cols:
        if feat not in df.columns or target_col not in df.columns:
            continue

        test_df = df[[target_col, feat]].dropna()
        if len(test_df) < max_lags * 3 + 10:
            continue

        try:
            result = grangercausalitytests(
                test_df, maxlag=max_lags, verbose=False
            )
            for lag in range(1, max_lags + 1):
                if lag in result:
                    for test_name, (f_stat, p_val, df1, df2) in result[lag][0].items():
                        if p_val < min_p:
                            min_p = p_val
        except Exception as e:
            log.debug(f"Granger test failed for {feat}: {e}")
            continue

    log.info(f"Granger min p-value: {min_p:.6f}")
    return min_p


# ---------------------------------------------------------------------------
# Walk-forward OOS validation
# ---------------------------------------------------------------------------

def walk_forward_oos(
    df: pd.DataFrame,
    target_col: str,
    feature_names: List[str],
    cfg: AppConfig,
) -> Tuple[float, float]:
    """
    Walk-forward out-of-sample validation.
    Split: first ~67% train, last ~33% test.
    Returns (oos_ic, oos_sharpe).
    """
    feat_cols = [f for f in feature_names if f in df.columns]
    if not feat_cols:
        return 0.0, 0.0

    clean = df[feat_cols + [target_col]].dropna()
    if len(clean) < 50:
        log.warning(f"Too few observations ({len(clean)}) for OOS validation")
        return 0.0, 0.0

    split_idx = int(len(clean) * 0.67)
    train = clean.iloc[:split_idx]
    test = clean.iloc[split_idx:]

    X_train = train[feat_cols].values
    y_train = train[target_col].values
    X_test = test[feat_cols].values
    y_test = test[target_col].values

    # Standardize
    scaler = StandardScaler()
    X_train_s = scaler.fit_transform(X_train)
    X_test_s = scaler.transform(X_test)

    # Fit LASSO on train
    alphas = np.logspace(
        np.log10(cfg.modeling.alpha_range_min),
        np.log10(cfg.modeling.alpha_range_max),
        20,
    )
    model = LassoCV(alphas=alphas, cv=3, max_iter=10000)
    try:
        model.fit(X_train_s, y_train)
    except Exception as e:
        log.error(f"OOS LASSO fit failed: {e}")
        return 0.0, 0.0

    # Predict on test
    y_pred = model.predict(X_test_s)

    # Information Coefficient (rank correlation)
    ic = float(np.corrcoef(y_pred, y_test)[0, 1])
    if np.isnan(ic):
        ic = 0.0

    # Simple long/short Sharpe
    positions = np.sign(y_pred)
    pnl = positions * y_test
    if pnl.std() > 0:
        # Annualize: ~78 5-min bars/day × 252 trading days
        sharpe = float(pnl.mean() / pnl.std()) * np.sqrt(78 * 252)
    else:
        sharpe = 0.0

    log.info(f"OOS validation: IC={ic:.4f}, Sharpe={sharpe:.4f}")
    return ic, sharpe


# ---------------------------------------------------------------------------
# Status classification
# ---------------------------------------------------------------------------

def classify_status(
    ols_results: Dict[str, Any],
    granger_p: float,
    oos_ic: float,
    oos_sharpe: float,
    cfg: AppConfig,
    previous_status: Optional[str] = None,
) -> str:
    """
    Assign a tier status: Null, Candidate, Verified, or Degraded.
    """
    p_values = ols_results.get("p_values", {})
    n_obs = ols_results.get("n_obs", 0)
    betas = ols_results.get("betas", {})

    # Null: no non-zero betas
    if not betas:
        return "Null"

    # Check if any beta has p < candidate threshold
    min_p = min(p_values.values()) if p_values else 1.0

    if min_p >= cfg.verification.candidate_p_value_max:
        return "Null"

    # Candidate: at least one significant beta
    is_candidate = min_p < cfg.verification.candidate_p_value_max

    # Verified checks
    is_verified = (
        is_candidate
        and min_p < cfg.verification.verified_p_value_max
        and granger_p < cfg.verification.verified_granger_p_max
        and oos_ic > cfg.verification.min_oos_ic_for_verified
        and oos_sharpe > cfg.verification.min_oos_sharpe_for_verified
        and n_obs >= cfg.verification.min_effective_obs_for_verified
    )

    if is_verified:
        return "Verified"

    # Degraded: was Verified before but no longer meets threshold
    if previous_status == "Verified" and is_candidate:
        return "Degraded"

    if is_candidate:
        return "Candidate"

    return "Null"


# ---------------------------------------------------------------------------
# Full modeling pipeline for one ticker
# ---------------------------------------------------------------------------

def run_modeling_pipeline(
    df: pd.DataFrame,
    target_col: str,
    ticker: str,
    market_ids: List[str],
    cfg: AppConfig,
    previous_status: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Execute the full statistical pipeline for one ticker.
    Returns a dict ready for insertion into pm_sentiment_library.
    """
    run_id = f"{datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S')}_{ticker}_{uuid.uuid4().hex[:8]}"
    now_str = datetime.now(timezone.utc).isoformat()

    base_result = {
        "run_id": run_id,
        "ticker": ticker,
        "run_timestamp": now_str,
        "window_start": None,
        "window_end": None,
        "status": "Null",
        "input_market_ids": market_ids,
        "significant_market_ids": [],
        "betas": {},
        "std_errors": {},
        "t_stats": {},
        "p_values": {},
        "adj_r2": None,
        "granger_p": None,
        "num_obs": 0,
        "oos_ic": None,
        "oos_sharpe": None,
        "decay_days": None,
    }

    if df.empty or target_col not in df.columns:
        log.warning(f"[{ticker}] Empty or invalid DataFrame — recording Null run")
        return base_result

    # Window
    if "timestamp" in df.columns:
        base_result["window_start"] = str(df["timestamp"].min())
        base_result["window_end"] = str(df["timestamp"].max())

    feature_names = _feature_columns(df, target_col)
    if not feature_names:
        log.warning(f"[{ticker}] No feature columns found — recording Null run")
        return base_result

    # Prepare arrays
    feat_df = df[feature_names + [target_col]].dropna()
    if len(feat_df) < cfg.tradfi.min_effective_observations:
        log.warning(
            f"[{ticker}] Only {len(feat_df)} observations "
            f"(need {cfg.tradfi.min_effective_observations}) — recording Null run"
        )
        base_result["num_obs"] = len(feat_df)
        return base_result

    X = feat_df[feature_names].values
    y = feat_df[target_col].values

    # Standardize features
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)

    # Sanity: no all-zero columns
    col_sums = np.abs(X_scaled).sum(axis=0)
    nonzero_cols = col_sums > 0
    if not nonzero_cols.all():
        dropped = [f for f, nz in zip(feature_names, nonzero_cols) if not nz]
        log.warning(f"[{ticker}] Dropping all-zero columns: {dropped}")
        X_scaled = X_scaled[:, nonzero_cols]
        feature_names = [f for f, nz in zip(feature_names, nonzero_cols) if nz]

    # --- LASSO CV ---
    model, coefs, alpha = fit_lasso_cv(X_scaled, y, cfg, feature_names)
    if model is None:
        return base_result

    # --- Post-LASSO OLS ---
    ols_results = post_lasso_ols(X_scaled, y, coefs, feature_names)
    base_result.update({
        "betas": ols_results["betas"],
        "std_errors": ols_results["std_errors"],
        "t_stats": ols_results["t_stats"],
        "p_values": ols_results["p_values"],
        "adj_r2": ols_results["adj_r2"],
        "num_obs": ols_results["n_obs"],
        "significant_market_ids": ols_results["significant_features"],
    })

    # --- Granger causality ---
    pm_logit_cols = [f for f in feature_names if "logit" in f and "lag" not in f]
    granger_p = granger_test(feat_df, target_col, pm_logit_cols)
    base_result["granger_p"] = granger_p

    # --- OOS validation ---
    sig_features = ols_results["significant_features"]
    if sig_features:
        oos_ic, oos_sharpe = walk_forward_oos(feat_df, target_col, sig_features, cfg)
    else:
        oos_ic, oos_sharpe = 0.0, 0.0
    base_result["oos_ic"] = oos_ic
    base_result["oos_sharpe"] = oos_sharpe

    # --- Status classification ---
    status = classify_status(
        ols_results, granger_p, oos_ic, oos_sharpe, cfg, previous_status
    )
    base_result["status"] = status

    log.info(
        f"[{ticker}] Pipeline complete: status={status}, "
        f"adj_r2={ols_results.get('adj_r2')}, granger_p={granger_p:.4f}, "
        f"oos_ic={oos_ic:.4f}, oos_sharpe={oos_sharpe:.4f}, "
        f"n_obs={ols_results['n_obs']}"
    )

    return base_result
