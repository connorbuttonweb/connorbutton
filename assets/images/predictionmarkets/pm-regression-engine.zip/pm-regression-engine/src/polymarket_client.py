"""
polymarket_client.py — Fetch active markets from Polymarket Gamma API + CLOB price history.
"""

import time
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Tuple

import pandas as pd
import requests

from src.config_loader import AppConfig
from src.logging_utils import get_logger

log = get_logger("polymarket")


class PolymarketClient:
    """Read-only client for Polymarket Gamma and CLOB REST APIs."""

    def __init__(self, cfg: AppConfig):
        self.cfg = cfg
        self.gamma_url = cfg.polymarket.gamma_base_url
        self.clob_url = cfg.polymarket.clob_base_url
        self.session = requests.Session()
        self.session.headers.update({
            "User-Agent": cfg.polymarket.user_agent,
            "Accept": "application/json",
        })

    # ------------------------------------------------------------------
    # Gamma — market discovery
    # ------------------------------------------------------------------

    def fetch_active_markets(self, max_markets: Optional[int] = None) -> List[Dict[str, Any]]:
        """
        Paginate through /markets?active=true and return raw market dicts.
        Stops at max_markets or when the API returns no more results.
        """
        limit = max_markets or self.cfg.polymarket.max_markets_per_run
        page_size = min(self.cfg.polymarket.page_size, limit)
        collected: List[Dict[str, Any]] = []
        offset = 0

        log.info(f"Fetching active markets from Gamma (limit={limit})…")

        while len(collected) < limit:
            url = f"{self.gamma_url}/markets"
            params = {
                "active": "true",
                "closed": "false",
                "limit": page_size,
                "offset": offset,
            }
            try:
                resp = self.session.get(url, params=params, timeout=30)
                resp.raise_for_status()
            except requests.RequestException as e:
                log.error(f"Gamma API error at offset {offset}: {e}")
                break

            data = resp.json()
            if not data:
                log.info(f"No more markets returned at offset {offset}")
                break

            collected.extend(data)
            offset += page_size
            log.debug(f"Fetched {len(collected)} markets so far (offset={offset})")
            time.sleep(self.cfg.polymarket.request_delay_seconds)

        # Trim to limit
        collected = collected[:limit]
        log.info(f"Total markets fetched: {len(collected)}")
        return collected

    def parse_market(self, raw: Dict[str, Any]) -> Dict[str, Any]:
        """Extract the fields we care about from a raw Gamma market dict."""
        # condition_id is the primary identifier; fall back to id
        market_id = raw.get("condition_id") or raw.get("id") or ""
        question = raw.get("question", "")
        tags_raw = raw.get("tags", [])
        if isinstance(tags_raw, str):
            import json
            try:
                tags_raw = json.loads(tags_raw)
            except Exception:
                tags_raw = [t.strip() for t in tags_raw.split(",") if t.strip()]

        end_date = raw.get("end_date_iso") or raw.get("end_date") or ""

        # Volume: Gamma provides volume or volume24hr
        vol = 0.0
        for key in ("volume24hr", "volume_num", "volume"):
            v = raw.get(key)
            if v is not None:
                try:
                    vol = float(v)
                    break
                except (ValueError, TypeError):
                    continue

        return {
            "market_id": str(market_id),
            "question_text": question,
            "resolution_date": end_date,
            "tags": tags_raw if isinstance(tags_raw, list) else [],
            "volume_24h": vol,
        }

    # ------------------------------------------------------------------
    # CLOB — token price history
    # ------------------------------------------------------------------

    def get_market_tokens(self, condition_id: str) -> List[Dict[str, Any]]:
        """
        Return available tokens for a condition_id via Gamma /markets?id=... lookup.
        Each token has: token_id, outcome (Yes/No), price.
        """
        url = f"{self.gamma_url}/markets"
        params = {"id": condition_id}
        try:
            resp = self.session.get(url, params=params, timeout=20)
            resp.raise_for_status()
            data = resp.json()
        except Exception as e:
            log.warning(f"Could not fetch token info for {condition_id}: {e}")
            return []

        # Gamma returns a list; we want the first match
        if isinstance(data, list) and data:
            market = data[0]
        elif isinstance(data, dict):
            market = data
        else:
            return []

        tokens = []
        # Check for clobTokenIds (JSON-encoded list)
        clob_ids_raw = market.get("clobTokenIds")
        outcomes_raw = market.get("outcomes")
        outcomePrices_raw = market.get("outcomePrices")

        if clob_ids_raw:
            import json
            try:
                clob_ids = json.loads(clob_ids_raw) if isinstance(clob_ids_raw, str) else clob_ids_raw
            except Exception:
                clob_ids = []
            try:
                outcomes = json.loads(outcomes_raw) if isinstance(outcomes_raw, str) else (outcomes_raw or [])
            except Exception:
                outcomes = []
            try:
                prices = json.loads(outcomePrices_raw) if isinstance(outcomePrices_raw, str) else (outcomePrices_raw or [])
            except Exception:
                prices = []

            for i, tid in enumerate(clob_ids):
                tokens.append({
                    "token_id": str(tid),
                    "outcome": outcomes[i] if i < len(outcomes) else f"Outcome_{i}",
                    "price": float(prices[i]) if i < len(prices) else None,
                })

        return tokens

    def pick_alpha_token(self, tokens: List[Dict[str, Any]]) -> Optional[str]:
        """
        Pick the 'alpha' token — Yes/Up or highest-price token.
        Returns the token_id string or None.
        """
        if not tokens:
            return None

        # Prefer 'Yes' outcome
        for t in tokens:
            if t.get("outcome", "").lower() in ("yes", "up"):
                return t["token_id"]

        # Fallback: highest price
        valid = [t for t in tokens if t.get("price") is not None]
        if valid:
            return max(valid, key=lambda t: t["price"])["token_id"]

        return tokens[0]["token_id"]

    def fetch_token_price_history(
        self,
        token_id: str,
        start_ts: int,
        end_ts: int,
        fidelity: int = 5,
    ) -> pd.DataFrame:
        """
        Fetch price/trade history for a CLOB token.
        Uses the Gamma /prices endpoint or CLOB timeseries.
        Returns DataFrame with columns: [timestamp, price].
        """
        # Try CLOB timeseries endpoint
        url = f"{self.clob_url}/prices-history"
        params = {
            "market": token_id,
            "startTs": start_ts,
            "endTs": end_ts,
            "fidelity": fidelity,
        }
        try:
            resp = self.session.get(url, params=params, timeout=30)
            resp.raise_for_status()
            data = resp.json()
        except Exception as e:
            log.warning(f"CLOB price history failed for token {token_id}: {e}")
            # Fallback: try Gamma timeseries
            return self._fetch_gamma_timeseries(token_id, start_ts, end_ts)

        if not data or "history" not in data:
            log.debug(f"No CLOB price history for token {token_id}, trying Gamma…")
            return self._fetch_gamma_timeseries(token_id, start_ts, end_ts)

        records = data["history"]
        if not records:
            return pd.DataFrame(columns=["timestamp", "price"])

        df = pd.DataFrame(records)
        # Normalize column names
        if "t" in df.columns and "p" in df.columns:
            df = df.rename(columns={"t": "timestamp", "p": "price"})
        elif "timestamp" not in df.columns:
            # Try common alternatives
            for tc in ("time", "ts"):
                if tc in df.columns:
                    df = df.rename(columns={tc: "timestamp"})
                    break
            for pc in ("price", "close", "mid"):
                if pc in df.columns:
                    df = df.rename(columns={pc: "price"})
                    break

        if "timestamp" in df.columns and "price" in df.columns:
            df["timestamp"] = pd.to_datetime(df["timestamp"], unit="s", utc=True, errors="coerce")
            df["price"] = pd.to_numeric(df["price"], errors="coerce")
            df = df.dropna(subset=["timestamp", "price"])
            return df[["timestamp", "price"]].sort_values("timestamp").reset_index(drop=True)

        log.warning(f"Unexpected CLOB response structure for token {token_id}")
        return pd.DataFrame(columns=["timestamp", "price"])

    def _fetch_gamma_timeseries(
        self, token_id: str, start_ts: int, end_ts: int
    ) -> pd.DataFrame:
        """Fallback: try Gamma /prices endpoint."""
        url = f"{self.gamma_url}/prices"
        params = {
            "market": token_id,
            "startTs": start_ts,
            "endTs": end_ts,
            "interval": "max",  # or "5m"
        }
        try:
            resp = self.session.get(url, params=params, timeout=30)
            resp.raise_for_status()
            data = resp.json()
        except Exception as e:
            log.warning(f"Gamma prices fallback also failed for {token_id}: {e}")
            return pd.DataFrame(columns=["timestamp", "price"])

        if isinstance(data, list) and data:
            df = pd.DataFrame(data)
            for tc in ("t", "time", "timestamp", "ts"):
                if tc in df.columns:
                    df = df.rename(columns={tc: "timestamp"})
                    break
            for pc in ("p", "price", "close"):
                if pc in df.columns:
                    df = df.rename(columns={pc: "price"})
                    break
            if "timestamp" in df.columns and "price" in df.columns:
                df["timestamp"] = pd.to_datetime(df["timestamp"], unit="s", utc=True, errors="coerce")
                df["price"] = pd.to_numeric(df["price"], errors="coerce")
                df = df.dropna(subset=["timestamp", "price"])
                return df[["timestamp", "price"]].sort_values("timestamp").reset_index(drop=True)

        return pd.DataFrame(columns=["timestamp", "price"])
