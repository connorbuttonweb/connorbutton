"""
llm_mapper.py — Use an LLM to map Polymarket questions → tradable tickers.
Includes caching to minimize API token usage.
"""

import hashlib
import json
import os
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from src.config_loader import AppConfig, get_openai_key
from src.logging_utils import get_logger

log = get_logger("llm_mapper")


# ---------------------------------------------------------------------------
# Cache helpers
# ---------------------------------------------------------------------------

def _cache_key(market_ids: List[str]) -> str:
    """Deterministic hash for a batch of market IDs."""
    joined = "|".join(sorted(market_ids))
    return hashlib.sha256(joined.encode()).hexdigest()[:16]


def _load_cache(cache_dir: str) -> Dict[str, Dict[str, Any]]:
    """Load all cached LLM responses (market_id → result)."""
    cache = {}
    cdir = Path(cache_dir)
    if not cdir.exists():
        return cache
    for f in cdir.glob("*.json"):
        try:
            with open(f) as fh:
                batch = json.load(fh)
            if isinstance(batch, dict) and "results" in batch:
                for entry in batch["results"]:
                    mid = entry.get("market_id")
                    if mid:
                        cache[mid] = entry
        except Exception:
            continue
    return cache


def _save_cache(cache_dir: str, batch_id: str, payload: Dict[str, Any]):
    """Persist an LLM batch response."""
    cdir = Path(cache_dir)
    cdir.mkdir(parents=True, exist_ok=True)
    path = cdir / f"batch_{batch_id}.json"
    with open(path, "w") as f:
        json.dump(payload, f, indent=2)


# ---------------------------------------------------------------------------
# LLM interaction
# ---------------------------------------------------------------------------

_SYSTEM_PROMPT = """You are a financial research assistant. Your task is to map prediction market questions to the single most relevant tradable ticker symbol (Yahoo Finance format).

Rules:
1. Map each question to EXACTLY ONE ticker or "NONE" if no clear mapping exists.
2. Use standard Yahoo Finance symbols: SPY, QQQ, BTC-USD, ETH-USD, GLD, TLT, DX-Y.NYB, CL=F, etc.
3. For Fed/interest rate questions → use TLT (long-term treasury ETF) or ^TNX.
4. For inflation questions → use TIP or CPI-related ETFs.
5. For crypto questions → use BTC-USD, ETH-USD, SOL-USD, etc.
6. For tariff/trade war questions → use the most affected index (SPY, EEM, FXI, etc.).
7. For election/political questions that don't clearly move a specific asset → "NONE".
8. Mark markets as duplicates if they ask essentially the same question.

Respond ONLY with valid JSON matching this schema:
{
  "results": [
    {
      "market_id": "<id>",
      "ticker": "<TICKER or NONE>",
      "confidence": <0.0-1.0>,
      "reasoning": "<one sentence>",
      "duplicate_of": "<market_id or null>"
    }
  ]
}"""


def _build_user_prompt(markets: List[Dict[str, Any]]) -> str:
    """Build the user message listing markets to map."""
    lines = ["Map each prediction market question to a Yahoo Finance ticker:\n"]
    for m in markets:
        lines.append(f'- ID: {m["market_id"]}\n  Q: {m.get("question_text", "")}\n')
    return "\n".join(lines)


def call_llm_batch(
    markets: List[Dict[str, Any]], cfg: AppConfig
) -> List[Dict[str, Any]]:
    """
    Call the LLM to map a batch of markets to tickers.
    Returns list of result dicts with keys: market_id, ticker, confidence, reasoning, duplicate_of.
    """
    api_key = get_openai_key()
    if not api_key:
        log.error("OPENAI_API_KEY not set — cannot run LLM mapping")
        return []

    try:
        from openai import OpenAI
        client = OpenAI(api_key=api_key)
    except ImportError:
        log.error("openai package not installed")
        return []

    user_msg = _build_user_prompt(markets)

    try:
        response = client.chat.completions.create(
            model=cfg.llm.model_name,
            messages=[
                {"role": "system", "content": _SYSTEM_PROMPT},
                {"role": "user", "content": user_msg},
            ],
            max_tokens=cfg.llm.max_tokens,
            temperature=cfg.llm.temperature,
        )
        content = response.choices[0].message.content.strip()
    except Exception as e:
        log.error(f"LLM API call failed: {e}")
        return []

    # Parse JSON from response (handle markdown fences)
    if content.startswith("```"):
        lines = content.split("\n")
        content = "\n".join(
            l for l in lines if not l.strip().startswith("```")
        )

    try:
        parsed = json.loads(content)
        results = parsed.get("results", [])
    except json.JSONDecodeError as e:
        log.error(f"LLM response is not valid JSON: {e}\nRaw: {content[:500]}")
        return []

    return results


# ---------------------------------------------------------------------------
# Main mapper
# ---------------------------------------------------------------------------

class LLMMapper:
    """Orchestrate LLM-based ticker mapping with caching."""

    def __init__(self, cfg: AppConfig):
        self.cfg = cfg
        self.cache_dir = cfg.llm.cache_dir
        self.cache = _load_cache(self.cache_dir)
        self.dry_run = cfg.llm.dry_run

    def map_markets(
        self, markets: List[Dict[str, Any]], ticker_validator=None
    ) -> List[Dict[str, Any]]:
        """
        Map a list of markets to tickers.
        - Skips markets already in cache.
        - Batches remaining markets per cfg.llm.batch_size.
        - Validates proposed tickers via ticker_validator (if provided).
        Returns list of mapping results.
        """
        if not self.cfg.llm.enabled:
            log.info("LLM mapping disabled in config")
            return []

        # Separate cached vs. uncached
        to_map = []
        cached_results = []
        for m in markets:
            mid = m["market_id"]
            if mid in self.cache:
                cached_results.append(self.cache[mid])
                log.debug(f"Cache hit for market {mid}")
            else:
                to_map.append(m)

        log.info(
            f"LLM mapping: {len(cached_results)} cached, {len(to_map)} need mapping"
        )

        # Respect max_markets_per_llm_run
        to_map = to_map[: self.cfg.llm.max_markets_per_llm_run]

        if not to_map:
            return cached_results

        # Batch and call LLM
        batch_size = self.cfg.llm.batch_size
        new_results = []

        for i in range(0, len(to_map), batch_size):
            batch = to_map[i : i + batch_size]
            batch_ids = [m["market_id"] for m in batch]
            bid = _cache_key(batch_ids)

            log.info(f"LLM batch {i // batch_size + 1}: {len(batch)} markets")

            if self.dry_run:
                log.info("[DRY RUN] Would call LLM for:")
                for m in batch:
                    log.info(f"  {m['market_id']}: {m.get('question_text', '')[:80]}")
                continue

            results = call_llm_batch(batch, self.cfg)

            # Validate tickers
            for r in results:
                ticker = r.get("ticker", "NONE")
                if ticker != "NONE" and ticker_validator:
                    if not ticker_validator(ticker):
                        log.warning(
                            f"Ticker {ticker} failed validation for market {r.get('market_id')}; "
                            f"forcing NONE"
                        )
                        r["ticker"] = "NONE"

            # Cache this batch
            payload = {"batch_id": bid, "results": results}
            _save_cache(self.cache_dir, bid, payload)
            for r in results:
                mid = r.get("market_id")
                if mid:
                    self.cache[mid] = r

            new_results.extend(results)

        all_results = cached_results + new_results
        log.info(f"LLM mapping complete: {len(all_results)} total results")
        return all_results
