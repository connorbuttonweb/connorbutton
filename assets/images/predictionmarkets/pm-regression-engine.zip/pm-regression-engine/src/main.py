"""
main.py — Orchestrate the full pipeline: discovery, mapping, ingestion, modeling, export.
Each phase is idempotent and can be run independently.
"""

import time
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Dict, List, Optional

import pandas as pd

from src.config_loader import AppConfig, find_project_root
from src.db import Database
from src.diagnostics import sanity_check_dataframe
from src.feature_engineering import (
    align_pm_to_tradfi,
    compute_features,
    ensure_stationarity,
)
from src.filters import MarketFilter
from src.logging_utils import get_logger, setup_logging
from src.modeling import run_modeling_pipeline
from src.polymarket_client import PolymarketClient
from src.tradfi_client import TradFiClient

log = get_logger("main")


# ===================================================================
# PHASE 1 — Market Discovery & Multi-Gate Prune
# ===================================================================

def phase1_discover_and_filter(cfg: AppConfig, db: Database) -> Dict:
    """
    Fetch active Polymarket markets and apply deterministic filters.
    Inserts survivors into the Markets table.
    Returns stats dict.
    """
    log.info("=" * 60)
    log.info("PHASE 1: Market Discovery & Multi-Gate Prune")
    log.info("=" * 60)

    pm_client = PolymarketClient(cfg)
    raw_markets = pm_client.fetch_active_markets()

    # Parse
    parsed = [pm_client.parse_market(m) for m in raw_markets]
    log.info(f"Parsed {len(parsed)} markets from Gamma API")

    # Filter
    mf = MarketFilter(cfg)
    survivors, stats = mf.apply(parsed)

    # Insert into DB
    db.bulk_upsert_markets(survivors)
    log.info(f"Phase 1 complete: {stats['survivors']} markets inserted/updated in DB")

    # Save debug CSV if enabled
    if cfg.general.debug_save_intermediates:
        root = find_project_root()
        df = pd.DataFrame(survivors)
        path = root / "data" / "debug" / "phase1_survivors.csv"
        df.to_csv(path, index=False)
        log.debug(f"Saved Phase 1 survivors → {path}")

    return stats


# ===================================================================
# PHASE 2 — Semantic Mapping & Deduplication
# ===================================================================

def phase2_map_and_dedup(cfg: AppConfig, db: Database) -> Dict:
    """
    Use embeddings for dedup and LLM for ticker mapping.
    Updates Markets table with matched_ticker and is_duplicate.
    """
    log.info("=" * 60)
    log.info("PHASE 2: Semantic Mapping & Deduplication")
    log.info("=" * 60)

    unmapped = db.get_unmapped_markets()
    log.info(f"Unmapped markets to process: {len(unmapped)}")

    if not unmapped:
        log.info("No unmapped markets — skipping Phase 2")
        return {"total_unmapped": 0, "duplicates": 0, "mapped": 0}

    stats = {"total_unmapped": len(unmapped), "duplicates": 0, "mapped": 0}

    # --- Embedding dedup ---
    from src.embeddings_dedup import EmbeddingDeduplicator
    deduper = EmbeddingDeduplicator(cfg)
    try:
        primaries, dup_ids = deduper.deduplicate(unmapped)
    except Exception as e:
        log.warning(f"Embedding dedup failed (continuing without): {e}")
        primaries = unmapped
        dup_ids = []

    # Mark duplicates in DB
    for mid in dup_ids:
        db.update_market_mapping(mid, ticker=None, is_duplicate=True)
    stats["duplicates"] = len(dup_ids)

    # --- LLM mapping ---
    from src.llm_mapper import LLMMapper
    tradfi = TradFiClient(cfg)
    mapper = LLMMapper(cfg)

    results = mapper.map_markets(
        primaries,
        ticker_validator=tradfi.validate_ticker,
    )

    # Apply mappings
    for r in results:
        mid = r.get("market_id")
        ticker = r.get("ticker")
        is_dup = r.get("duplicate_of") is not None

        if not mid:
            continue

        if is_dup:
            db.update_market_mapping(mid, ticker=None, is_duplicate=True)
            stats["duplicates"] += 1
        elif ticker and ticker != "NONE":
            db.update_market_mapping(mid, ticker=ticker, is_duplicate=False)
            stats["mapped"] += 1
        else:
            # Explicitly set to empty string to avoid re-processing
            db.update_market_mapping(mid, ticker="NONE", is_duplicate=False)

    log.info(
        f"Phase 2 complete: {stats['mapped']} mapped, "
        f"{stats['duplicates']} duplicates"
    )
    return stats


# ===================================================================
# PHASE 3 — Targeted Data Ingestion
# ===================================================================

def phase3_ingest_data(
    cfg: AppConfig,
    db: Database,
    ticker: Optional[str] = None,
) -> Dict[str, Dict]:
    """
    Fetch TradFi + Polymarket data for mapped tickers.
    Returns {ticker: {"tradfi": df, "pm_series": {mid: df}}}.
    """
    log.info("=" * 60)
    log.info("PHASE 3: Targeted Data Ingestion")
    log.info("=" * 60)

    if ticker:
        tickers = [ticker]
    else:
        tickers = [t for t in db.get_mapped_tickers() if t and t != "NONE"]

    log.info(f"Tickers to ingest: {len(tickers)}")

    tradfi = TradFiClient(cfg)
    pm_client = PolymarketClient(cfg)

    save_raw = cfg.general.debug_save_intermediates
    data_store = {}

    for t in tickers:
        log.info(f"[{t}] Ingesting data…")

        # TradFi bars
        tf_df = tradfi.fetch_bars(t, save_raw=save_raw)
        if tf_df.empty:
            log.warning(f"[{t}] No TradFi data — skipping")
            continue

        # Polymarket series
        markets = db.get_markets_for_ticker(t)
        pm_series = {}

        end_ts = int(datetime.now(timezone.utc).timestamp())
        start_ts = int(
            (datetime.now(timezone.utc) - timedelta(days=cfg.tradfi.lookback_days)).timestamp()
        )

        for m in markets:
            mid = m["market_id"]

            # Get tokens
            tokens = pm_client.get_market_tokens(mid)
            alpha_token = pm_client.pick_alpha_token(tokens)

            if not alpha_token:
                log.debug(f"[{t}] No alpha token for market {mid}")
                continue

            # Fetch price history
            pm_df = pm_client.fetch_token_price_history(
                alpha_token, start_ts, end_ts
            )
            if not pm_df.empty:
                pm_series[mid] = pm_df
                log.debug(f"[{t}] Market {mid}: {len(pm_df)} price points")

                # Save raw if debug
                if save_raw:
                    root = find_project_root()
                    path = root / "data" / "raw" / f"pm_{mid[:16]}.csv"
                    pm_df.to_csv(path, index=False)

        data_store[t] = {"tradfi": tf_df, "pm_series": pm_series}
        log.info(f"[{t}] Ingested: {len(tf_df)} TradFi bars, {len(pm_series)} PM series")

    log.info(f"Phase 3 complete: {len(data_store)} tickers with data")
    return data_store


# ===================================================================
# PHASE 4 — Data Cleaning, Alignment & Transformation
# ===================================================================

def phase4_transform(
    data_store: Dict,
    cfg: AppConfig,
) -> Dict[str, tuple]:
    """
    Align and compute features for each ticker.
    Returns {ticker: (features_df, target_col)}.
    """
    log.info("=" * 60)
    log.info("PHASE 4: Data Cleaning, Alignment & Transformation")
    log.info("=" * 60)

    results = {}

    for ticker, data in data_store.items():
        tf_df = data["tradfi"]
        pm_series = data["pm_series"]

        if tf_df.empty or not pm_series:
            log.warning(f"[{ticker}] Missing data — skipping")
            continue

        # Align
        aligned = align_pm_to_tradfi(tf_df, pm_series, cfg)
        if aligned.empty:
            log.warning(f"[{ticker}] Alignment produced empty DataFrame")
            continue

        # Compute features
        feat_df, target_col = compute_features(aligned, cfg)
        if feat_df.empty:
            log.warning(f"[{ticker}] Feature computation produced empty DataFrame")
            continue

        # Stationarity checks on logit columns + returns
        logit_cols = [c for c in feat_df.columns if "logit" in c and "lag" not in c]
        check_cols = logit_cols + [target_col]
        feat_df, dropped = ensure_stationarity(feat_df, check_cols, cfg)

        if target_col in dropped:
            log.warning(f"[{ticker}] Returns dropped as non-stationary — skipping")
            continue

        # Save intermediate if debug
        if cfg.general.debug_save_intermediates:
            root = find_project_root()
            path = root / "data" / "processed" / f"features_{ticker.replace('-', '_')}.csv"
            feat_df.to_csv(path, index=False)
            log.debug(f"Saved features → {path}")

        results[ticker] = (feat_df, target_col)
        log.info(f"[{ticker}] Features ready: {len(feat_df)} rows, {len(feat_df.columns)} cols")

    log.info(f"Phase 4 complete: {len(results)} tickers with features")
    return results


# ===================================================================
# PHASE 5 — Statistical Engine
# ===================================================================

def phase5_model(
    features_store: Dict[str, tuple],
    cfg: AppConfig,
    db: Database,
) -> List[Dict]:
    """
    Run the full modeling pipeline for each ticker.
    Returns list of run result dicts.
    """
    log.info("=" * 60)
    log.info("PHASE 5: Statistical Engine")
    log.info("=" * 60)

    run_results = []

    for ticker, (feat_df, target_col) in features_store.items():
        # Sanity check
        if not sanity_check_dataframe(
            feat_df, target_col,
            min_obs=cfg.tradfi.min_effective_observations,
            label=ticker,
        ):
            log.warning(f"[{ticker}] Failed sanity checks — recording Null run")

        # Get market IDs for this ticker
        markets = db.get_markets_for_ticker(ticker)
        market_ids = [m["market_id"] for m in markets]

        # Check previous status for Degraded logic
        prev_run = db.get_latest_run(ticker)
        prev_status = prev_run["status"] if prev_run else None

        # Run the full pipeline
        result = run_modeling_pipeline(
            feat_df, target_col, ticker, market_ids, cfg, prev_status
        )
        run_results.append(result)

    log.info(f"Phase 5 complete: {len(run_results)} ticker runs")
    return run_results


# ===================================================================
# PHASE 6 — Research Library Persistence & Exports
# ===================================================================

def phase6_persist_and_export(
    run_results: List[Dict],
    cfg: AppConfig,
    db: Database,
) -> Dict:
    """
    Persist run results to DB and generate exports.
    """
    log.info("=" * 60)
    log.info("PHASE 6: Research Library Persistence & Exports")
    log.info("=" * 60)

    # Persist
    for result in run_results:
        db.insert_run(result)

    log.info(f"Persisted {len(run_results)} runs to DB")

    # Exports
    from src.library_export import export_json, export_excel

    root = find_project_root()
    json_path = export_json(db, cfg, str(root / "exports" / "json"))
    excel_path = export_excel(db, cfg, str(root / "exports" / "excel"))

    stats = {
        "runs_persisted": len(run_results),
        "json_path": json_path,
        "excel_path": excel_path,
        "status_counts": {},
    }

    for r in run_results:
        s = r.get("status", "Null")
        stats["status_counts"][s] = stats["status_counts"].get(s, 0) + 1

    log.info(f"Phase 6 complete: {stats}")
    return stats


# ===================================================================
# Full pipeline orchestration
# ===================================================================

def run_full_pipeline(
    cfg: AppConfig,
    db: Database,
    ticker: Optional[str] = None,
    smoke_test: bool = False,
):
    """
    Run all 6 phases end-to-end.
    If ticker is specified, only processes that ticker (phases 3-6).
    If smoke_test, limits to 1 ticker with short lookback.
    """
    start_time = time.time()

    if smoke_test:
        log.info("🔬 SMOKE TEST MODE — limited scope")
        cfg.polymarket.max_markets_per_run = 50
        cfg.tradfi.lookback_days = 3
        cfg.tradfi.min_effective_observations = 20
        cfg.llm.max_markets_per_llm_run = 5
        cfg.llm.batch_size = 5

    try:
        # Phase 1
        if not ticker:
            phase1_discover_and_filter(cfg, db)

        # Phase 2
        if not ticker:
            phase2_map_and_dedup(cfg, db)

        # Phase 3
        data_store = phase3_ingest_data(cfg, db, ticker=ticker)

        if smoke_test and data_store:
            # Limit to first ticker
            first_key = next(iter(data_store))
            data_store = {first_key: data_store[first_key]}

        # Phase 4
        features_store = phase4_transform(data_store, cfg)

        # Phase 5
        run_results = phase5_model(features_store, cfg, db)

        # Phase 6
        stats = phase6_persist_and_export(run_results, cfg, db)

        elapsed = time.time() - start_time
        log.info(f"Full pipeline complete in {elapsed:.1f}s")
        return stats

    except KeyboardInterrupt:
        log.warning("Pipeline interrupted by user (Ctrl+C). DB is safe.")
        raise
    except Exception as e:
        log.error(f"Pipeline failed: {e}", exc_info=True)
        raise
