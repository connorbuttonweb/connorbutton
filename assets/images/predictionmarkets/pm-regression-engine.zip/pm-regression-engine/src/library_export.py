"""
library_export.py — Export the sentiment library to JSON and styled Excel.
"""

import json
from pathlib import Path
from typing import List, Dict, Any

import pandas as pd

from src.config_loader import AppConfig
from src.db import Database
from src.logging_utils import get_logger

log = get_logger("export")


def export_json(db: Database, cfg: AppConfig, output_dir: str = "exports/json") -> str:
    """
    Export library runs to a JSON file.
    If json_verified_only, only include Verified runs.
    Returns the output file path.
    """
    out_dir = Path(output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    if cfg.exports.json_verified_only:
        runs = db.get_verified_runs()
        filename = "verified_relationships.json"
    else:
        runs = db.get_all_runs()
        filename = "all_relationships.json"

    # Clean up JSON fields (they're stored as strings in SQLite)
    export_data = []
    for run in runs:
        entry = dict(run)
        for json_field in [
            "input_market_ids", "significant_market_ids",
            "betas", "std_errors", "t_stats", "p_values",
        ]:
            val = entry.get(json_field)
            if isinstance(val, str):
                try:
                    entry[json_field] = json.loads(val)
                except (json.JSONDecodeError, TypeError):
                    pass
        export_data.append(entry)

    out_path = out_dir / filename
    with open(out_path, "w") as f:
        json.dump(export_data, f, indent=2, default=str)

    log.info(f"Exported {len(export_data)} runs → {out_path}")
    return str(out_path)


def export_excel(
    db: Database, cfg: AppConfig, output_dir: str = "exports/excel"
) -> str:
    """
    Export library runs to a styled Excel file with conditional formatting.
    Returns the output file path.
    """
    out_dir = Path(output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    runs = db.get_all_runs()
    if not runs:
        log.info("No runs to export")
        return ""

    # Build DataFrame
    records = []
    for run in runs:
        entry = dict(run)
        # Parse JSON fields into readable strings
        for json_field in ["betas", "p_values"]:
            val = entry.get(json_field)
            if isinstance(val, str):
                try:
                    parsed = json.loads(val)
                    # Show top features by absolute beta
                    if isinstance(parsed, dict):
                        entry[json_field] = "; ".join(
                            f"{k}={v:.4f}" if isinstance(v, (int, float)) else f"{k}={v}"
                            for k, v in sorted(
                                parsed.items(),
                                key=lambda x: abs(x[1]) if isinstance(x[1], (int, float)) else 0,
                                reverse=True,
                            )[:5]
                        )
                except Exception:
                    pass
        # Simplify list fields
        for list_field in ["input_market_ids", "significant_market_ids"]:
            val = entry.get(list_field)
            if isinstance(val, str):
                try:
                    parsed = json.loads(val)
                    entry[list_field] = len(parsed) if isinstance(parsed, list) else val
                except Exception:
                    pass
        # Remove raw JSON fields we've already processed
        for drop_field in ["std_errors", "t_stats"]:
            entry.pop(drop_field, None)
        records.append(entry)

    df = pd.DataFrame(records)

    # Reorder columns
    priority_cols = [
        "ticker", "status", "run_timestamp", "adj_r2", "granger_p",
        "oos_ic", "oos_sharpe", "num_obs", "betas", "p_values",
    ]
    ordered = [c for c in priority_cols if c in df.columns]
    ordered += [c for c in df.columns if c not in ordered]
    df = df[ordered]

    out_path = out_dir / "library_snapshot.xlsx"

    with pd.ExcelWriter(str(out_path), engine="openpyxl") as writer:
        df.to_excel(writer, index=False, sheet_name="Library")

        if cfg.exports.excel_conditional_formatting:
            _apply_formatting(writer, df)

        # Summary sheet
        summary = _build_summary(df)
        summary.to_excel(writer, index=True, sheet_name="Summary")

    log.info(f"Exported {len(df)} runs → {out_path}")
    return str(out_path)


def _apply_formatting(writer, df: pd.DataFrame):
    """Apply conditional formatting to the Excel workbook."""
    from openpyxl.styles import PatternFill, Font
    from openpyxl.utils import get_column_letter

    ws = writer.sheets["Library"]

    status_colors = {
        "Verified": PatternFill(start_color="C6EFCE", end_color="C6EFCE", fill_type="solid"),
        "Candidate": PatternFill(start_color="FFEB9C", end_color="FFEB9C", fill_type="solid"),
        "Degraded": PatternFill(start_color="FFC7CE", end_color="FFC7CE", fill_type="solid"),
        "Null": PatternFill(start_color="D9D9D9", end_color="D9D9D9", fill_type="solid"),
    }

    # Find status column
    status_col_idx = None
    for idx, col in enumerate(df.columns, start=1):
        if col == "status":
            status_col_idx = idx
            break

    if status_col_idx:
        for row in range(2, len(df) + 2):  # skip header
            cell = ws.cell(row=row, column=status_col_idx)
            fill = status_colors.get(cell.value)
            if fill:
                cell.fill = fill

    # Bold header
    for col_idx in range(1, len(df.columns) + 1):
        ws.cell(row=1, column=col_idx).font = Font(bold=True)

    # Auto-width columns
    for col_idx in range(1, len(df.columns) + 1):
        col_letter = get_column_letter(col_idx)
        max_len = max(
            len(str(ws.cell(row=r, column=col_idx).value or ""))
            for r in range(1, min(len(df) + 2, 100))
        )
        ws.column_dimensions[col_letter].width = min(max_len + 2, 40)


def _build_summary(df: pd.DataFrame) -> pd.DataFrame:
    """Build a summary pivot of status counts and avg metrics per ticker."""
    if df.empty:
        return pd.DataFrame()

    summary = df.groupby("status").agg(
        count=("ticker", "size"),
        avg_adj_r2=("adj_r2", "mean"),
        avg_oos_ic=("oos_ic", "mean"),
        avg_oos_sharpe=("oos_sharpe", "mean"),
        avg_granger_p=("granger_p", "mean"),
    ).round(4)

    return summary
