"""
db.py — SQLite database layer with migration-safe schema init.
"""

import json
import sqlite3
from contextlib import contextmanager
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from src.logging_utils import get_logger

log = get_logger("db")

# ---------------------------------------------------------------------------
# Schema DDL
# ---------------------------------------------------------------------------

_SCHEMA_SQL = """
-- Markets table: Polymarket metadata + ticker mappings
CREATE TABLE IF NOT EXISTS Markets (
    market_id   TEXT PRIMARY KEY,
    question_text TEXT,
    resolution_date TEXT,
    tags        TEXT,           -- JSON array
    volume_24h  REAL,
    matched_ticker TEXT DEFAULT NULL,
    is_duplicate INTEGER DEFAULT 0,
    created_at  DATETIME DEFAULT (datetime('now')),
    updated_at  DATETIME DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_markets_ticker ON Markets(matched_ticker);
CREATE INDEX IF NOT EXISTS idx_markets_resolution ON Markets(resolution_date);
CREATE INDEX IF NOT EXISTS idx_markets_dup ON Markets(is_duplicate);

-- Sentiment library: run results per ticker
CREATE TABLE IF NOT EXISTS pm_sentiment_library (
    run_id              TEXT PRIMARY KEY,
    ticker              TEXT NOT NULL,
    run_timestamp       DATETIME NOT NULL,
    window_start        DATETIME,
    window_end          DATETIME,
    status              TEXT NOT NULL DEFAULT 'Null',
    input_market_ids    TEXT,       -- JSON array
    significant_market_ids TEXT,    -- JSON array
    betas               TEXT,       -- JSON {feature: value}
    std_errors          TEXT,       -- JSON
    t_stats             TEXT,       -- JSON
    p_values            TEXT,       -- JSON
    adj_r2              REAL,
    granger_p           REAL,
    num_obs             INTEGER,
    oos_ic              REAL,
    oos_sharpe          REAL,
    decay_days          INTEGER DEFAULT NULL,
    created_at          DATETIME DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_lib_ticker ON pm_sentiment_library(ticker);
CREATE INDEX IF NOT EXISTS idx_lib_ticker_ts ON pm_sentiment_library(ticker, run_timestamp);
CREATE INDEX IF NOT EXISTS idx_lib_status ON pm_sentiment_library(status);

-- Schema version tracking
CREATE TABLE IF NOT EXISTS _schema_version (
    version INTEGER PRIMARY KEY,
    applied_at DATETIME DEFAULT (datetime('now'))
);
"""

CURRENT_SCHEMA_VERSION = 1


# ---------------------------------------------------------------------------
# Connection helpers
# ---------------------------------------------------------------------------

class Database:
    """Thin SQLite wrapper with migration support."""

    def __init__(self, db_path: str):
        self.db_path = Path(db_path)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._conn: Optional[sqlite3.Connection] = None

    def connect(self) -> sqlite3.Connection:
        if self._conn is None:
            self._conn = sqlite3.connect(
                str(self.db_path),
                timeout=30,
                check_same_thread=False,
            )
            self._conn.row_factory = sqlite3.Row
            self._conn.execute("PRAGMA journal_mode=WAL")
            self._conn.execute("PRAGMA foreign_keys=ON")
        return self._conn

    def close(self):
        if self._conn:
            self._conn.close()
            self._conn = None

    @contextmanager
    def transaction(self):
        conn = self.connect()
        try:
            yield conn
            conn.commit()
        except Exception:
            conn.rollback()
            raise

    # ------------------------------------------------------------------
    # Schema init / migration
    # ------------------------------------------------------------------

    def init_schema(self):
        """Create tables idempotently."""
        conn = self.connect()
        conn.executescript(_SCHEMA_SQL)
        conn.commit()

        # Record version
        existing = conn.execute(
            "SELECT MAX(version) FROM _schema_version"
        ).fetchone()[0]
        if existing is None or existing < CURRENT_SCHEMA_VERSION:
            conn.execute(
                "INSERT OR REPLACE INTO _schema_version(version) VALUES(?)",
                (CURRENT_SCHEMA_VERSION,),
            )
            conn.commit()
        log.info(f"Database initialized at {self.db_path} (schema v{CURRENT_SCHEMA_VERSION})")

    # ------------------------------------------------------------------
    # Markets CRUD
    # ------------------------------------------------------------------

    def upsert_market(self, market: Dict[str, Any]):
        """Insert or update a market row."""
        conn = self.connect()
        conn.execute(
            """
            INSERT INTO Markets (market_id, question_text, resolution_date, tags, volume_24h)
            VALUES (?, ?, ?, ?, ?)
            ON CONFLICT(market_id) DO UPDATE SET
                question_text = excluded.question_text,
                resolution_date = excluded.resolution_date,
                tags = excluded.tags,
                volume_24h = excluded.volume_24h,
                updated_at = datetime('now')
            """,
            (
                market["market_id"],
                market.get("question_text"),
                market.get("resolution_date"),
                json.dumps(market.get("tags", [])),
                market.get("volume_24h", 0.0),
            ),
        )
        conn.commit()

    def bulk_upsert_markets(self, markets: List[Dict[str, Any]]):
        """Batch insert/update markets."""
        conn = self.connect()
        conn.executemany(
            """
            INSERT INTO Markets (market_id, question_text, resolution_date, tags, volume_24h)
            VALUES (?, ?, ?, ?, ?)
            ON CONFLICT(market_id) DO UPDATE SET
                question_text = excluded.question_text,
                resolution_date = excluded.resolution_date,
                tags = excluded.tags,
                volume_24h = excluded.volume_24h,
                updated_at = datetime('now')
            """,
            [
                (
                    m["market_id"],
                    m.get("question_text"),
                    m.get("resolution_date"),
                    json.dumps(m.get("tags", [])),
                    m.get("volume_24h", 0.0),
                )
                for m in markets
            ],
        )
        conn.commit()

    def get_unmapped_markets(self) -> List[Dict[str, Any]]:
        """Return markets without a ticker mapping and not marked duplicate."""
        conn = self.connect()
        rows = conn.execute(
            "SELECT * FROM Markets WHERE matched_ticker IS NULL AND is_duplicate = 0"
        ).fetchall()
        return [dict(r) for r in rows]

    def update_market_mapping(
        self, market_id: str, ticker: Optional[str], is_duplicate: bool = False
    ):
        """Set matched_ticker and is_duplicate for a market."""
        conn = self.connect()
        conn.execute(
            """
            UPDATE Markets SET
                matched_ticker = ?,
                is_duplicate = ?,
                updated_at = datetime('now')
            WHERE market_id = ?
            """,
            (ticker, int(is_duplicate), market_id),
        )
        conn.commit()

    def get_mapped_tickers(self) -> List[str]:
        """Return distinct tickers with active (non-dup) mappings."""
        conn = self.connect()
        rows = conn.execute(
            "SELECT DISTINCT matched_ticker FROM Markets "
            "WHERE matched_ticker IS NOT NULL AND is_duplicate = 0"
        ).fetchall()
        return [r[0] for r in rows]

    def get_markets_for_ticker(self, ticker: str) -> List[Dict[str, Any]]:
        """Return all non-dup markets mapped to a given ticker."""
        conn = self.connect()
        rows = conn.execute(
            "SELECT * FROM Markets WHERE matched_ticker = ? AND is_duplicate = 0",
            (ticker,),
        ).fetchall()
        return [dict(r) for r in rows]

    # ------------------------------------------------------------------
    # Sentiment library CRUD
    # ------------------------------------------------------------------

    def insert_run(self, run: Dict[str, Any]):
        """Insert a new run into pm_sentiment_library."""
        conn = self.connect()
        conn.execute(
            """
            INSERT OR REPLACE INTO pm_sentiment_library (
                run_id, ticker, run_timestamp, window_start, window_end,
                status, input_market_ids, significant_market_ids,
                betas, std_errors, t_stats, p_values,
                adj_r2, granger_p, num_obs, oos_ic, oos_sharpe, decay_days
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                run["run_id"],
                run["ticker"],
                run["run_timestamp"],
                run.get("window_start"),
                run.get("window_end"),
                run.get("status", "Null"),
                json.dumps(run.get("input_market_ids", [])),
                json.dumps(run.get("significant_market_ids", [])),
                json.dumps(run.get("betas", {})),
                json.dumps(run.get("std_errors", {})),
                json.dumps(run.get("t_stats", {})),
                json.dumps(run.get("p_values", {})),
                run.get("adj_r2"),
                run.get("granger_p"),
                run.get("num_obs"),
                run.get("oos_ic"),
                run.get("oos_sharpe"),
                run.get("decay_days"),
            ),
        )
        conn.commit()

    def get_latest_run(self, ticker: str) -> Optional[Dict[str, Any]]:
        """Return the most recent run for a ticker."""
        conn = self.connect()
        row = conn.execute(
            """
            SELECT * FROM pm_sentiment_library
            WHERE ticker = ?
            ORDER BY run_timestamp DESC
            LIMIT 1
            """,
            (ticker,),
        ).fetchone()
        return dict(row) if row else None

    def get_runs_by_status(self, status: str) -> List[Dict[str, Any]]:
        """Return all runs with a given status."""
        conn = self.connect()
        rows = conn.execute(
            "SELECT * FROM pm_sentiment_library WHERE status = ? ORDER BY run_timestamp DESC",
            (status,),
        ).fetchall()
        return [dict(r) for r in rows]

    def get_all_runs(self) -> List[Dict[str, Any]]:
        """Return every run, newest first."""
        conn = self.connect()
        rows = conn.execute(
            "SELECT * FROM pm_sentiment_library ORDER BY run_timestamp DESC"
        ).fetchall()
        return [dict(r) for r in rows]

    def get_verified_runs(self) -> List[Dict[str, Any]]:
        """Return all Verified runs, sorted by adj_r2 descending."""
        conn = self.connect()
        rows = conn.execute(
            """
            SELECT * FROM pm_sentiment_library
            WHERE status = 'Verified'
            ORDER BY adj_r2 DESC
            """,
        ).fetchall()
        return [dict(r) for r in rows]

    def count_markets(self) -> int:
        conn = self.connect()
        return conn.execute("SELECT COUNT(*) FROM Markets").fetchone()[0]

    def count_runs(self) -> int:
        conn = self.connect()
        return conn.execute("SELECT COUNT(*) FROM pm_sentiment_library").fetchone()[0]
