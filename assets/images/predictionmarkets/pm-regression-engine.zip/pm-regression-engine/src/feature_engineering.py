"""
feature_engineering.py — Align TradFi and Polymarket series, compute features.
"""

from typing import Dict, List, Optional, Tuple

import numpy as np
import pandas as pd
from statsmodels.tsa.stattools import adfuller, kpss

from src.config_loader import AppConfig
from src.logging_utils import get_logger

log = get_logger("features")


# ---------------------------------------------------------------------------
# Alignment
# ---------------------------------------------------------------------------

def align_pm_to_tradfi(
    tradfi_df: pd.DataFrame,
    pm_series: Dict[str, pd.DataFrame],
    cfg: AppConfig,
) -> pd.DataFrame:
    """
    Align multiple Polymarket price series onto the TradFi 5-min grid.

    Parameters
    ----------
    tradfi_df : DataFrame with [timestamp, open, high, low, close, volume]
    pm_series : dict of {market_id: DataFrame with [timestamp, price]}
    cfg       : AppConfig

    Returns
    -------
    DataFrame with columns:
      timestamp, tradfi_close, tradfi_volume,
      pm_{market_id}_price (one per market),
      ...forward-filled and cleaned.
    """
    if tradfi_df.empty:
        log.warning("Empty TradFi DataFrame — cannot align")
        return pd.DataFrame()

    master = tradfi_df[["timestamp", "close", "volume"]].copy()
    master = master.rename(columns={"close": "tradfi_close", "volume": "tradfi_volume"})
    master = master.sort_values("timestamp").reset_index(drop=True)

    for mid, pm_df in pm_series.items():
        if pm_df.empty:
            log.debug(f"Skipping empty PM series {mid}")
            continue

        pm = pm_df[["timestamp", "price"]].copy()
        pm = pm.sort_values("timestamp").reset_index(drop=True)
        pm = pm.rename(columns={"price": f"pm_{mid}_price"})

        # merge_asof: snap PM trades to nearest prior TradFi bar
        tolerance = pd.Timedelta(minutes=cfg.transform.max_merge_gap_minutes)
        master = pd.merge_asof(
            master,
            pm,
            on="timestamp",
            direction="backward",
            tolerance=tolerance,
        )

    # Forward-fill PM prices
    pm_cols = [c for c in master.columns if c.startswith("pm_")]
    master[pm_cols] = master[pm_cols].ffill()

    # Optionally drop rows with no PM trades
    if cfg.transform.drop_zero_trade_bins and pm_cols:
        # Keep rows where at least one PM column has data
        mask = master[pm_cols].notna().any(axis=1)
        before = len(master)
        master = master[mask].reset_index(drop=True)
        log.debug(f"Dropped {before - len(master)} zero-trade bins")

    log.info(f"Aligned DataFrame: {len(master)} rows, {len(pm_cols)} PM series")
    return master


# ---------------------------------------------------------------------------
# Feature computation
# ---------------------------------------------------------------------------

def compute_features(
    aligned_df: pd.DataFrame,
    cfg: AppConfig,
) -> Tuple[pd.DataFrame, str]:
    """
    Compute all features for modeling.

    Returns (features_df, target_col) where target_col is the column name
    of the dependent variable (TradFi returns).
    """
    df = aligned_df.copy()

    if df.empty or "tradfi_close" not in df.columns:
        log.warning("Empty or malformed aligned DF — no features to compute")
        return pd.DataFrame(), ""

    # --- TradFi returns ---
    df["returns"] = df["tradfi_close"].pct_change()
    target_col = "returns"

    # --- Polymarket logits ---
    eps = cfg.transform.logit_clip_epsilon
    pm_cols = [c for c in df.columns if c.startswith("pm_") and c.endswith("_price")]
    logit_cols = []
    for pc in pm_cols:
        p_clipped = df[pc].clip(lower=eps, upper=1.0 - eps)
        logit_col = pc.replace("_price", "_logit")
        df[logit_col] = np.log(p_clipped / (1.0 - p_clipped))
        logit_cols.append(logit_col)

    # --- Lagged PM logits ---
    lag_pm_cols = []
    for lc in logit_cols:
        for lag in range(1, cfg.modeling.max_lags_pm + 1):
            col_name = f"{lc}_lag{lag}"
            df[col_name] = df[lc].shift(lag)
            lag_pm_cols.append(col_name)

    # --- Autoregressive lags of returns ---
    lag_ret_cols = []
    for lag in range(1, cfg.modeling.max_lags_returns + 1):
        col_name = f"returns_lag{lag}"
        df[col_name] = df["returns"].shift(lag)
        lag_ret_cols.append(col_name)

    # --- Calendar dummies ---
    dummy_cols = []
    if cfg.transform.add_market_open_dummy and "timestamp" in df.columns:
        # US market open: 9:30-10:00 ET → 13:30-14:00 UTC (approx)
        hour = df["timestamp"].dt.hour
        minute = df["timestamp"].dt.minute
        df["market_open"] = ((hour == 13) & (minute >= 30) | (hour == 14) & (minute == 0)).astype(int)
        dummy_cols.append("market_open")

    if cfg.transform.add_hour_of_day_dummies and "timestamp" in df.columns:
        df["hour"] = df["timestamp"].dt.hour
        hour_dummies = pd.get_dummies(df["hour"], prefix="hour", drop_first=True, dtype=int)
        df = pd.concat([df, hour_dummies], axis=1)
        dummy_cols.extend(hour_dummies.columns.tolist())
        df = df.drop(columns=["hour"])

    if cfg.transform.add_day_of_week_dummies and "timestamp" in df.columns:
        df["dow"] = df["timestamp"].dt.dayofweek
        dow_dummies = pd.get_dummies(df["dow"], prefix="dow", drop_first=True, dtype=int)
        df = pd.concat([df, dow_dummies], axis=1)
        dummy_cols.extend(dow_dummies.columns.tolist())
        df = df.drop(columns=["dow"])

    # Drop NaN rows from lagging
    max_lag = max(cfg.modeling.max_lags_pm, cfg.modeling.max_lags_returns)
    df = df.iloc[max_lag:].reset_index(drop=True)

    # Drop any remaining NaNs in target
    df = df.dropna(subset=[target_col])

    feature_cols = logit_cols + lag_pm_cols + lag_ret_cols + dummy_cols
    log.info(
        f"Features computed: {len(feature_cols)} features, "
        f"{len(df)} observations, target='{target_col}'"
    )

    return df, target_col


# ---------------------------------------------------------------------------
# Stationarity checks
# ---------------------------------------------------------------------------

def check_stationarity(
    series: pd.Series,
    series_name: str,
    cfg: AppConfig,
) -> Tuple[bool, str]:
    """
    Run ADF and KPSS tests. Return (is_stationary, report_string).
    """
    report_lines = [f"Stationarity check: {series_name}"]
    clean = series.dropna()

    if len(clean) < 20:
        msg = f"  Too few observations ({len(clean)}) for stationarity tests"
        report_lines.append(msg)
        return False, "\n".join(report_lines)

    # ADF
    try:
        adf_stat, adf_p, _, _, _, _ = adfuller(clean, autolag="AIC")
        report_lines.append(f"  ADF: stat={adf_stat:.4f}, p={adf_p:.4f}")
        adf_pass = adf_p < cfg.stationarity.adf_p_threshold
    except Exception as e:
        report_lines.append(f"  ADF failed: {e}")
        adf_pass = False

    # KPSS
    try:
        kpss_stat, kpss_p, _, _ = kpss(clean, regression="c", nlags="auto")
        report_lines.append(f"  KPSS: stat={kpss_stat:.4f}, p={kpss_p:.4f}")
        kpss_pass = kpss_p >= cfg.stationarity.kpss_p_threshold  # KPSS H0 = stationary
    except Exception as e:
        report_lines.append(f"  KPSS failed: {e}")
        kpss_pass = True  # give benefit of doubt

    is_stationary = adf_pass and kpss_pass
    report_lines.append(f"  → {'STATIONARY' if is_stationary else 'NON-STATIONARY'}")

    return is_stationary, "\n".join(report_lines)


def ensure_stationarity(
    df: pd.DataFrame,
    columns: List[str],
    cfg: AppConfig,
) -> Tuple[pd.DataFrame, List[str]]:
    """
    Check stationarity of given columns. Apply fallback_strategy if non-stationary.
    Returns (modified_df, dropped_columns).
    """
    dropped = []
    for col in columns:
        if col not in df.columns:
            continue
        is_stat, report = check_stationarity(df[col], col, cfg)
        log.debug(report)

        if not is_stat:
            if cfg.stationarity.fallback_strategy == "difference":
                log.info(f"Differencing non-stationary column: {col}")
                df[col] = df[col].diff()
            elif cfg.stationarity.fallback_strategy == "drop_asset":
                log.info(f"Dropping non-stationary column: {col}")
                df = df.drop(columns=[col])
                dropped.append(col)

    # Drop NaN rows from differencing
    df = df.dropna().reset_index(drop=True)
    return df, dropped
