"""
logging_utils.py — Structured logging with loguru, writing to console + rotating file.
"""

import sys
from pathlib import Path

from loguru import logger

_INITIALIZED = False


def setup_logging(log_level: str = "INFO", log_file: str = "logs/engine.log") -> None:
    """Configure loguru: console + rotating file output."""
    global _INITIALIZED
    if _INITIALIZED:
        return
    _INITIALIZED = True

    logger.remove()  # Remove default stderr handler

    # Console handler
    logger.add(
        sys.stderr,
        level=log_level.upper(),
        format=(
            "<green>{time:YYYY-MM-DD HH:mm:ss}</green> | "
            "<level>{level: <8}</level> | "
            "<cyan>{name}</cyan>:<cyan>{function}</cyan>:<cyan>{line}</cyan> — "
            "<level>{message}</level>"
        ),
        colorize=True,
    )

    # File handler (rotating 10 MB, keep 5 files)
    log_path = Path(log_file)
    log_path.parent.mkdir(parents=True, exist_ok=True)
    logger.add(
        str(log_path),
        level="DEBUG",  # File always captures DEBUG+
        rotation="10 MB",
        retention=5,
        format=(
            "{time:YYYY-MM-DD HH:mm:ss.SSS} | {level: <8} | "
            "{name}:{function}:{line} — {message}"
        ),
    )


def get_logger(name: str = "engine"):
    """Return a contextualized loguru logger."""
    return logger.bind(name=name)
