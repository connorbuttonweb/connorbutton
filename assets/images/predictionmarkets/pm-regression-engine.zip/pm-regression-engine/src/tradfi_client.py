"""
tradfi_client.py — Fetch TradFi OHLCV data via yfinance.
"""

from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Optional

import pandas as pd
import yfinance as yf

from src.config_loader import AppConfig
from src.logging_utils import get_logger

log = get_logger("tradfi")


class TradFiClient:
    """Fetch high-frequency bar data from Yahoo Finance."""

    def __init__(self, cfg: AppConfig):
        self.cfg = cfg
        self.interval = f"{cfg.tradfi.bar_interval_minutes}m"
        self.lookback_days = cfg.tradfi.lookback_days

    def fetch_bars(
        self,
        ticker: str,
        lookback_days: Optional[int] = None,
        save_raw: bool = False,
        raw_dir: str = "data/raw",
    ) -> pd.DataFrame:
        """
        Fetch intraday OHLCV bars for `ticker`.

        yfinance constraints for intraday:
          - 5m interval: max 60 days of history
          - Data is returned in the exchange's timezone; we convert to UTC.

        Returns DataFrame with columns:
          [timestamp, open, high, low, close, volume]
        where timestamp is UTC datetime.
        """
        days = lookback_days or self.lookback_days

        # yfinance limits 5m data to ~60 days
        if days > 59:
            log.warning(f"yfinance 5m limit is ~60 days; clamping {days} → 59")
            days = 59

        end_dt = datetime.now(timezone.utc)
        start_dt = end_dt - timedelta(days=days)

        log.info(
            f"Fetching {self.interval} bars for {ticker}: "
            f"{start_dt.date()} → {end_dt.date()} ({days}d)"
        )

        try:
            tf = yf.Ticker(ticker)
            df = tf.history(
                start=start_dt.strftime("%Y-%m-%d"),
                end=end_dt.strftime("%Y-%m-%d"),
                interval=self.interval,
                auto_adjust=True,
            )
        except Exception as e:
            log.error(f"yfinance fetch failed for {ticker}: {e}")
            return pd.DataFrame()

        if df.empty:
            log.warning(f"No data returned for {ticker}")
            return pd.DataFrame()

        # Normalize
        df = df.reset_index()
        # The index column may be named 'Datetime' or 'Date'
        time_col = None
        for c in ("Datetime", "Date", "datetime", "date"):
            if c in df.columns:
                time_col = c
                break
        if time_col is None:
            log.error(f"Cannot find timestamp column in yfinance output for {ticker}")
            return pd.DataFrame()

        df = df.rename(columns={
            time_col: "timestamp",
            "Open": "open",
            "High": "high",
            "Low": "low",
            "Close": "close",
            "Volume": "volume",
        })

        # Ensure UTC
        if df["timestamp"].dt.tz is None:
            df["timestamp"] = df["timestamp"].dt.tz_localize("UTC")
        else:
            df["timestamp"] = df["timestamp"].dt.tz_convert("UTC")

        df = df[["timestamp", "open", "high", "low", "close", "volume"]].copy()
        df = df.sort_values("timestamp").reset_index(drop=True)

        log.info(f"{ticker}: fetched {len(df)} bars ({df['timestamp'].min()} → {df['timestamp'].max()})")

        # Optionally persist raw CSV
        if save_raw:
            raw_path = Path(raw_dir) / f"tradfi_{ticker.replace('-', '_')}.csv"
            raw_path.parent.mkdir(parents=True, exist_ok=True)
            df.to_csv(raw_path, index=False)
            log.debug(f"Saved raw bars → {raw_path}")

        return df

    def validate_ticker(self, ticker: str) -> bool:
        """Quick check that yfinance returns at least 1 bar for a ticker."""
        try:
            tf = yf.Ticker(ticker)
            hist = tf.history(period="5d", interval="1d")
            if hist is not None and not hist.empty:
                return True
        except Exception:
            pass
        log.debug(f"Ticker validation failed: {ticker}")
        return False
