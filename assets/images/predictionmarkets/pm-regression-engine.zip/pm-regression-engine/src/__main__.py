"""Allow running via `python -m src`."""
from src.cli import main
main()
