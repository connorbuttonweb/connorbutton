"""
filters.py — Deterministic multi-gate filter for Polymarket markets.
"""

import re
from typing import Any, Dict, List, Tuple

from src.config_loader import AppConfig
from src.logging_utils import get_logger

log = get_logger("filters")


class MarketFilter:
    """Apply tag, keyword, and volume filters to raw market dicts."""

    def __init__(self, cfg: AppConfig):
        self.excluded_tags = set(t.lower() for t in cfg.filters.excluded_tags)
        self.excluded_patterns = [
            re.compile(kw, re.IGNORECASE)
            for kw in cfg.filters.excluded_keywords_regex
        ]
        self.min_volume = cfg.filters.min_24h_volume_absolute
        self.dyn_threshold = cfg.filters.dynamic_volume_share_threshold

    def apply(
        self, markets: List[Dict[str, Any]]
    ) -> Tuple[List[Dict[str, Any]], Dict[str, int]]:
        """
        Filter markets and return (survivors, stats).
        stats keys: total, dropped_tags, dropped_keywords, dropped_volume, survivors.
        """
        stats = {
            "total": len(markets),
            "dropped_tags": 0,
            "dropped_keywords": 0,
            "dropped_volume": 0,
            "survivors": 0,
        }

        survivors = []

        for m in markets:
            # --- Tag filter ---
            tags = m.get("tags", [])
            if isinstance(tags, str):
                import json
                try:
                    tags = json.loads(tags)
                except Exception:
                    tags = []
            tag_lower = set(t.lower() for t in tags)
            if tag_lower & self.excluded_tags:
                stats["dropped_tags"] += 1
                continue

            # --- Keyword filter ---
            question = m.get("question_text", "")
            if any(pat.search(question) for pat in self.excluded_patterns):
                stats["dropped_keywords"] += 1
                continue

            # --- Volume filter ---
            vol = m.get("volume_24h", 0.0)
            if vol < self.min_volume:
                stats["dropped_volume"] += 1
                continue

            survivors.append(m)

        stats["survivors"] = len(survivors)

        log.info(
            f"Filter results: {stats['total']} total → "
            f"{stats['dropped_tags']} tag-dropped, "
            f"{stats['dropped_keywords']} keyword-dropped, "
            f"{stats['dropped_volume']} volume-dropped → "
            f"{stats['survivors']} survivors"
        )

        return survivors, stats
