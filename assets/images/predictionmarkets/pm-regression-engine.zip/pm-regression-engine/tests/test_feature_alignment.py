"""
test_feature_alignment.py — Test data alignment and feature engineering on synthetic data.
"""

import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path

import numpy as np
import pandas as pd
import pytest

PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

from src.config_loader import AppConfig
from src.feature_engineering import (
    align_pm_to_tradfi,
    compute_features,
    check_stationarity,
)


def _make_tradfi_df(n_bars: int = 200) -> pd.DataFrame:
    """Generate synthetic 5-min TradFi bar data."""
    base_time = datetime(2026, 3, 10, 14, 0, tzinfo=timezone.utc)
    timestamps = [base_time + timedelta(minutes=5 * i) for i in range(n_bars)]
    close = 100.0 + np.cumsum(np.random.randn(n_bars) * 0.1)
    volume = np.random.randint(1000, 10000, n_bars)
    return pd.DataFrame({
        "timestamp": pd.to_datetime(timestamps, utc=True),
        "open": close + np.random.randn(n_bars) * 0.05,
        "high": close + abs(np.random.randn(n_bars) * 0.1),
        "low": close - abs(np.random.randn(n_bars) * 0.1),
        "close": close,
        "volume": volume,
    })


def _make_pm_df(n_trades: int = 150) -> pd.DataFrame:
    """Generate synthetic PM price data (probability between 0.1 and 0.9)."""
    base_time = datetime(2026, 3, 10, 14, 2, tzinfo=timezone.utc)
    timestamps = [base_time + timedelta(minutes=np.random.randint(0, 1000)) for _ in range(n_trades)]
    timestamps.sort()
    prices = np.clip(0.5 + np.cumsum(np.random.randn(n_trades) * 0.01), 0.05, 0.95)
    return pd.DataFrame({
        "timestamp": pd.to_datetime(timestamps, utc=True),
        "price": prices,
    })


class TestAlignment:
    def test_basic_alignment(self):
        """TradFi and PM data can be aligned onto a common grid."""
        cfg = AppConfig()
        tradfi = _make_tradfi_df(200)
        pm = {"mkt_001": _make_pm_df(150)}

        aligned = align_pm_to_tradfi(tradfi, pm, cfg)
        assert not aligned.empty
        assert "tradfi_close" in aligned.columns
        assert "pm_mkt_001_price" in aligned.columns

    def test_multiple_pm_series(self):
        """Multiple PM series can be aligned simultaneously."""
        cfg = AppConfig()
        tradfi = _make_tradfi_df(200)
        pm = {
            "mkt_001": _make_pm_df(100),
            "mkt_002": _make_pm_df(80),
        }

        aligned = align_pm_to_tradfi(tradfi, pm, cfg)
        assert "pm_mkt_001_price" in aligned.columns
        assert "pm_mkt_002_price" in aligned.columns

    def test_empty_pm_series_handled(self):
        """Empty PM series don't crash alignment."""
        cfg = AppConfig()
        tradfi = _make_tradfi_df(100)
        pm = {"mkt_empty": pd.DataFrame(columns=["timestamp", "price"])}

        aligned = align_pm_to_tradfi(tradfi, pm, cfg)
        # Should still have TradFi data
        assert "tradfi_close" in aligned.columns


class TestFeatureComputation:
    def test_features_computed(self):
        """Features are computed correctly from aligned data."""
        cfg = AppConfig()
        cfg.modeling.max_lags_pm = 2
        cfg.modeling.max_lags_returns = 2
        cfg.transform.add_hour_of_day_dummies = False
        cfg.transform.add_day_of_week_dummies = False
        cfg.transform.add_market_open_dummy = False
        cfg.transform.drop_zero_trade_bins = False

        tradfi = _make_tradfi_df(300)
        pm = {"mkt_001": _make_pm_df(200)}
        aligned = align_pm_to_tradfi(tradfi, pm, cfg)

        feat_df, target_col = compute_features(aligned, cfg)
        assert target_col == "returns"
        assert "returns" in feat_df.columns
        assert "pm_mkt_001_logit" in feat_df.columns
        assert "pm_mkt_001_logit_lag1" in feat_df.columns
        assert "returns_lag1" in feat_df.columns
        assert not feat_df["returns"].isna().any()

    def test_logit_transform_bounds(self):
        """Logit transform doesn't produce inf values."""
        cfg = AppConfig()
        cfg.transform.logit_clip_epsilon = 1e-6
        cfg.transform.drop_zero_trade_bins = False
        cfg.transform.add_hour_of_day_dummies = False
        cfg.transform.add_day_of_week_dummies = False
        cfg.transform.add_market_open_dummy = False

        tradfi = _make_tradfi_df(100)
        pm = {"mkt_001": _make_pm_df(80)}
        aligned = align_pm_to_tradfi(tradfi, pm, cfg)
        feat_df, _ = compute_features(aligned, cfg)

        logit_cols = [c for c in feat_df.columns if "logit" in c]
        for c in logit_cols:
            assert not feat_df[c].isna().all(), f"Column {c} is all NaN"
            finite_vals = feat_df[c].dropna()
            if len(finite_vals) > 0:
                assert np.isfinite(finite_vals).all(), f"Column {c} has non-finite values"


class TestStationarity:
    def test_stationary_series(self):
        """A white noise series should pass stationarity tests."""
        cfg = AppConfig()
        series = pd.Series(np.random.randn(500))
        is_stat, report = check_stationarity(series, "white_noise", cfg)
        # White noise should generally be stationary
        assert "white_noise" in report

    def test_nonstationary_series(self):
        """A random walk should fail stationarity tests."""
        cfg = AppConfig()
        series = pd.Series(np.cumsum(np.random.randn(500)))
        is_stat, report = check_stationarity(series, "random_walk", cfg)
        # A random walk should typically be non-stationary
        assert "random_walk" in report
