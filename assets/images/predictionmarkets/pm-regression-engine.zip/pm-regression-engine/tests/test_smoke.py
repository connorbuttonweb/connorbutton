"""
test_smoke.py — Smoke tests: DB init, config loading, CLI parsing.
"""

import os
import sys
import tempfile
from pathlib import Path

import pytest

# Ensure project root is importable
PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_ROOT))


class TestConfigLoader:
    def test_load_config_defaults(self):
        """AppConfig can be created with all defaults."""
        from src.config_loader import AppConfig
        cfg = AppConfig()
        assert cfg.general.db_path == "db/pm_sentiment_engine.db"
        assert cfg.modeling.model_type == "lasso"
        assert cfg.tradfi.bar_interval_minutes == 5

    def test_load_config_from_yaml(self):
        """Config loads from the project's config.yaml."""
        from src.config_loader import load_config
        cfg = load_config(str(PROJECT_ROOT / "config.yaml"))
        assert cfg.polymarket.gamma_base_url.startswith("https://")
        assert cfg.filters.min_24h_volume_absolute >= 0


class TestDatabase:
    def test_init_schema(self):
        """Database schema can be created in a temp file."""
        from src.db import Database
        with tempfile.NamedTemporaryFile(suffix=".db", delete=False) as f:
            db_path = f.name
        try:
            db = Database(db_path)
            db.init_schema()
            assert db.count_markets() == 0
            assert db.count_runs() == 0
        finally:
            db.close()
            os.unlink(db_path)

    def test_upsert_and_query_market(self):
        """Can insert a market and retrieve it."""
        from src.db import Database
        with tempfile.NamedTemporaryFile(suffix=".db", delete=False) as f:
            db_path = f.name
        try:
            db = Database(db_path)
            db.init_schema()
            db.upsert_market({
                "market_id": "test_123",
                "question_text": "Will BTC hit 100K?",
                "resolution_date": "2026-12-31",
                "tags": ["Crypto"],
                "volume_24h": 1000.0,
            })
            assert db.count_markets() == 1
            unmapped = db.get_unmapped_markets()
            assert len(unmapped) == 1
            assert unmapped[0]["market_id"] == "test_123"
        finally:
            db.close()
            os.unlink(db_path)

    def test_update_mapping(self):
        """Can update a market's ticker mapping."""
        from src.db import Database
        with tempfile.NamedTemporaryFile(suffix=".db", delete=False) as f:
            db_path = f.name
        try:
            db = Database(db_path)
            db.init_schema()
            db.upsert_market({
                "market_id": "m1",
                "question_text": "Test",
                "tags": [],
                "volume_24h": 500,
            })
            db.update_market_mapping("m1", "SPY")
            tickers = db.get_mapped_tickers()
            assert "SPY" in tickers
        finally:
            db.close()
            os.unlink(db_path)

    def test_insert_and_query_run(self):
        """Can insert a run and retrieve it."""
        from src.db import Database
        with tempfile.NamedTemporaryFile(suffix=".db", delete=False) as f:
            db_path = f.name
        try:
            db = Database(db_path)
            db.init_schema()
            db.insert_run({
                "run_id": "run_001",
                "ticker": "SPY",
                "run_timestamp": "2026-03-16T12:00:00",
                "status": "Verified",
                "adj_r2": 0.15,
                "granger_p": 0.02,
                "num_obs": 1000,
                "oos_ic": 0.08,
                "oos_sharpe": 0.7,
            })
            latest = db.get_latest_run("SPY")
            assert latest is not None
            assert latest["status"] == "Verified"
            verified = db.get_verified_runs()
            assert len(verified) == 1
        finally:
            db.close()
            os.unlink(db_path)


class TestFilters:
    def test_tag_filter(self):
        """Markets with excluded tags are dropped."""
        from src.config_loader import AppConfig
        from src.filters import MarketFilter

        cfg = AppConfig()
        cfg.filters.excluded_tags = ["Sports"]
        cfg.filters.min_24h_volume_absolute = 0
        mf = MarketFilter(cfg)

        markets = [
            {"market_id": "1", "question_text": "Test", "tags": ["Sports"], "volume_24h": 1000},
            {"market_id": "2", "question_text": "Test", "tags": ["Finance"], "volume_24h": 1000},
        ]
        survivors, stats = mf.apply(markets)
        assert len(survivors) == 1
        assert survivors[0]["market_id"] == "2"
        assert stats["dropped_tags"] == 1

    def test_keyword_filter(self):
        """Markets with excluded keywords are dropped."""
        from src.config_loader import AppConfig
        from src.filters import MarketFilter

        cfg = AppConfig()
        cfg.filters.excluded_keywords_regex = ["Taylor Swift"]
        cfg.filters.min_24h_volume_absolute = 0
        mf = MarketFilter(cfg)

        markets = [
            {"market_id": "1", "question_text": "Will Taylor Swift win?", "tags": [], "volume_24h": 1000},
            {"market_id": "2", "question_text": "Will SPY hit 500?", "tags": [], "volume_24h": 1000},
        ]
        survivors, stats = mf.apply(markets)
        assert len(survivors) == 1
        assert stats["dropped_keywords"] == 1

    def test_volume_filter(self):
        """Markets below volume threshold are dropped."""
        from src.config_loader import AppConfig
        from src.filters import MarketFilter

        cfg = AppConfig()
        cfg.filters.min_24h_volume_absolute = 500
        mf = MarketFilter(cfg)

        markets = [
            {"market_id": "1", "question_text": "Test", "tags": [], "volume_24h": 100},
            {"market_id": "2", "question_text": "Test", "tags": [], "volume_24h": 600},
        ]
        survivors, stats = mf.apply(markets)
        assert len(survivors) == 1
        assert stats["dropped_volume"] == 1


class TestCLIParsing:
    def test_cli_help(self):
        """CLI --help exits cleanly."""
        from click.testing import CliRunner
        from src.cli import cli
        runner = CliRunner()
        result = runner.invoke(cli, ["--help"])
        assert result.exit_code == 0
        assert "Polymarket" in result.output

    def test_cli_init_db(self):
        """CLI init-db command works."""
        from click.testing import CliRunner
        from src.cli import cli
        runner = CliRunner()
        # This will use the project's config.yaml
        result = runner.invoke(cli, ["init-db"])
        assert result.exit_code == 0
