"""
test_modeling_small_sample.py — Test the modeling pipeline on a small synthetic dataset.
"""

import sys
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import pandas as pd
import pytest

PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

from src.config_loader import AppConfig
from src.modeling import (
    fit_lasso_cv,
    post_lasso_ols,
    classify_status,
    walk_forward_oos,
    run_modeling_pipeline,
)


def _make_synthetic_features(n: int = 600) -> pd.DataFrame:
    """
    Generate a synthetic feature matrix with a known signal.
    Feature 'signal' predicts 'returns' with noise.
    """
    np.random.seed(42)
    timestamps = pd.date_range(
        "2026-03-01", periods=n, freq="5min", tz="UTC"
    )
    signal = np.random.randn(n) * 0.01
    noise1 = np.random.randn(n) * 0.005
    noise2 = np.random.randn(n) * 0.005
    returns = 0.3 * signal + np.random.randn(n) * 0.01

    return pd.DataFrame({
        "timestamp": timestamps,
        "tradfi_close": 100 + np.cumsum(returns),
        "tradfi_volume": np.random.randint(1000, 5000, n),
        "pm_mkt1_logit": signal + noise1,
        "pm_mkt1_logit_lag1": np.roll(signal + noise1, 1),
        "pm_mkt1_logit_lag2": np.roll(signal + noise1, 2),
        "pm_mkt2_logit": noise2,  # pure noise — should get zeroed by LASSO
        "returns_lag1": np.roll(returns, 1),
        "returns_lag2": np.roll(returns, 2),
        "returns": returns,
    })


class TestLassoCV:
    def test_lasso_cv_fits(self):
        """LassoCV fits on synthetic data without errors."""
        cfg = AppConfig()
        df = _make_synthetic_features(600)
        feature_names = [
            "pm_mkt1_logit", "pm_mkt1_logit_lag1", "pm_mkt1_logit_lag2",
            "pm_mkt2_logit", "returns_lag1", "returns_lag2",
        ]
        X = df[feature_names].values
        y = df["returns"].values

        model, coefs, alpha = fit_lasso_cv(X, y, cfg, feature_names)
        assert model is not None
        assert len(coefs) == len(feature_names)
        assert alpha > 0

    def test_lasso_selects_signal(self):
        """LASSO should retain the signal feature and zero out pure noise."""
        np.random.seed(123)
        cfg = AppConfig()
        cfg.modeling.n_alphas = 50
        cfg.modeling.alpha_range_min = 1e-6
        cfg.modeling.alpha_range_max = 0.1
        n = 1000
        signal = np.random.randn(n) * 0.02
        noise = np.random.randn(n) * 0.005
        returns = 0.8 * signal + np.random.randn(n) * 0.005
        df = pd.DataFrame({
            "signal": signal,
            "noise": noise,
        })
        X = df.values
        y = returns

        model, coefs, _ = fit_lasso_cv(X, y, cfg, ["signal", "noise"])
        # Signal feature should have non-zero coef
        assert coefs[0] != 0, "Signal feature was zeroed out"


class TestPostLassoOLS:
    def test_ols_runs(self):
        """Post-LASSO OLS produces valid output."""
        cfg = AppConfig()
        df = _make_synthetic_features(600)
        feature_names = [
            "pm_mkt1_logit", "pm_mkt1_logit_lag1",
            "pm_mkt2_logit", "returns_lag1",
        ]
        X = df[feature_names].values
        y = df["returns"].values

        model, coefs, _ = fit_lasso_cv(X, y, cfg, feature_names)
        result = post_lasso_ols(X, y, coefs, feature_names)

        assert "betas" in result
        assert "p_values" in result
        assert result["n_obs"] == len(y)

    def test_null_when_no_features(self):
        """Returns empty result when all coefs are zero."""
        result = post_lasso_ols(
            np.random.randn(100, 3),
            np.random.randn(100),
            np.zeros(3),
            ["a", "b", "c"],
        )
        assert result["betas"] == {}
        assert result["significant_features"] == []


class TestStatusClassification:
    def test_null_no_betas(self):
        """Null status when no betas."""
        cfg = AppConfig()
        result = {"betas": {}, "p_values": {}, "n_obs": 100}
        assert classify_status(result, 1.0, 0, 0, cfg) == "Null"

    def test_candidate(self):
        """Candidate status with weak p-value."""
        cfg = AppConfig()
        result = {
            "betas": {"feat1": 0.01},
            "p_values": {"feat1": 0.08},
            "n_obs": 600,
        }
        assert classify_status(result, 0.5, 0.03, 0.3, cfg) == "Candidate"

    def test_verified(self):
        """Verified status with all thresholds met."""
        cfg = AppConfig()
        result = {
            "betas": {"feat1": 0.01},
            "p_values": {"feat1": 0.01},
            "n_obs": 600,
        }
        status = classify_status(result, 0.02, 0.1, 0.8, cfg)
        assert status == "Verified"


class TestWalkForwardOOS:
    def test_oos_returns_values(self):
        """Walk-forward OOS returns IC and Sharpe."""
        cfg = AppConfig()
        df = _make_synthetic_features(600)
        feature_names = ["pm_mkt1_logit", "pm_mkt1_logit_lag1", "returns_lag1"]
        ic, sharpe = walk_forward_oos(df, "returns", feature_names, cfg)
        # Values should be finite
        assert np.isfinite(ic)
        assert np.isfinite(sharpe)


class TestFullPipeline:
    def test_modeling_pipeline_synthetic(self):
        """Full modeling pipeline runs on synthetic data."""
        cfg = AppConfig()
        cfg.tradfi.min_effective_observations = 50
        df = _make_synthetic_features(600)

        result = run_modeling_pipeline(
            df, "returns", "TEST_TICKER", ["mkt1", "mkt2"], cfg
        )

        assert result["ticker"] == "TEST_TICKER"
        assert result["status"] in ("Null", "Candidate", "Verified", "Degraded")
        assert result["num_obs"] > 0
        assert result["run_id"] is not None
