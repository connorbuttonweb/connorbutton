"""
llm_mapper.py — Use an LLM to map Polymarket questions → tradable tickers.
Includes caching to minimize API token usage.
"""

import hashlib
import json
import os
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from src.config_loader import AppConfig, get_openai_key
from src.logging_utils import get_logger

log = get_logger("llm_mapper")


# ---------------------------------------------------------------------------
# Cache helpers
# ---------------------------------------------------------------------------

def _cache_key(market_ids: List[str]) -> str:
    """Deterministic hash for a batch of market IDs."""
    joined = "|".join(sorted(market_ids))
    return hashlib.sha256(joined.encode()).hexdigest()[:16]


def _load_cache(cache_dir: str) -> Dict[str, Dict[str, Any]]:
    """Load all cached LLM responses (market_id → result)."""
    cache = {}
    cdir = Path(cache_dir)
    if not cdir.exists():
        return cache
    for f in cdir.glob("*.json"):
        try:
            with open(f) as fh:
                batch = json.load(fh)
            if isinstance(batch, dict) and "results" in batch:
                for entry in batch["results"]:
                    mid = entry.get("market_id")
                    if mid:
                        cache[mid] = entry
        except Exception:
            continue
    return cache


def _save_cache(cache_dir: str, batch_id: str, payload: Dict[str, Any]):
    """Persist an LLM batch response."""
    cdir = Path(cache_dir)
    cdir.mkdir(parents=True, exist_ok=True)
    path = cdir / f"batch_{batch_id}.json"
    with open(path, "w") as f:
        json.dump(payload, f, indent=2)


# ---------------------------------------------------------------------------
# LLM interaction
# ---------------------------------------------------------------------------

_SYSTEM_PROMPT = """You are a quantitative finance researcher mapping prediction market questions to the single most relevant tradable ticker (Yahoo Finance format). Be AGGRESSIVE about finding connections — these markets have already been pre-filtered to financial/macro topics.

Mapping rules (use the FIRST matching rule):
1. Fed funds / interest rate questions → TLT
2. Inflation / CPI questions → TIP
3. US recession / GDP / unemployment → SPY
4. Bitcoin / BTC price questions → BTC-USD
5. Ethereum / ETH price or ecosystem (including L2s, DeFi) → ETH-USD
6. Solana / SOL → SOL-USD
7. Other specific crypto tokens → map to their Yahoo symbol (e.g., XRP-USD, DOGE-USD)
8. Crypto market cap / broad crypto → BTC-USD
9. Oil / OPEC / energy supply → CL=F
10. Gold / safe-haven demand → GLD
11. China-Taiwan conflict / China trade / China sanctions → FXI
12. Russia-Ukraine war / ceasefire → RSX or CL=F (pick the stronger link)
13. US tariffs / trade war → SPY
14. Government shutdown / debt ceiling / US default → TLT
15. Specific US company questions (Nvidia, Apple, Tesla, Microsoft, etc.) → that company's ticker (NVDA, AAPL, TSLA, MSFT, etc.)
16. "Largest company by market cap" → the company most likely referenced (NVDA, AAPL, MSFT)
17. Broad AI / tech dominance → QQQ
18. US dollar / currency → DX-Y.NYB
19. If the question is about a political figure's ECONOMIC POLICY impact → SPY
20. Questions about celebrities, sports, entertainment, pure politics with no asset link → "NONE"

When multiple markets ask variants of the same question (e.g., "Will 1/2/3/4 Fed rate cuts happen?"), map ALL of them to the same ticker. They are NOT duplicates — each variant carries different probability information. Only mark true duplicates (identical questions).

Be concise in reasoning (under 15 words). Respond ONLY with valid JSON:
{
  "results": [
    {
      "market_id": "<id>",
      "ticker": "<TICKER or NONE>",
      "confidence": <0.0-1.0>,
      "reasoning": "<short>",
      "duplicate_of": "<market_id or null>"
    }
  ]
}"""


def _salvage_truncated_json(raw: str) -> List[Dict[str, Any]]:
    """
    When the LLM response is truncated (max_tokens hit), try to extract
    all complete JSON objects from the partial "results" array.
    """
    import re
    results = []
    # Find all complete {...} blocks that look like result entries
    # Match from opening { to the next }, being careful with nested braces
    pattern = re.compile(
        r'\{\s*"market_id"\s*:.*?"duplicate_of"\s*:\s*(?:null|"[^"]*")\s*\}',
        re.DOTALL,
    )
    for match in pattern.finditer(raw):
        try:
            obj = json.loads(match.group())
            if "market_id" in obj and "ticker" in obj:
                results.append(obj)
        except json.JSONDecodeError:
            continue
    return results


def _build_user_prompt(markets: List[Dict[str, Any]]) -> str:
    """Build the user message listing markets to map."""
    lines = ["Map each prediction market question to a Yahoo Finance ticker:\n"]
    for m in markets:
        lines.append(f'- ID: {m["market_id"]}\n  Q: {m.get("question_text", "")}\n')
    return "\n".join(lines)


def call_llm_batch(
    markets: List[Dict[str, Any]], cfg: AppConfig
) -> List[Dict[str, Any]]:
    """
    Call the LLM to map a batch of markets to tickers.
    Returns list of result dicts with keys: market_id, ticker, confidence, reasoning, duplicate_of.
    """
    api_key = get_openai_key()
    if not api_key:
        log.error("OPENAI_API_KEY not set — cannot run LLM mapping")
        return []

    try:
        from openai import OpenAI
        client = OpenAI(api_key=api_key)
    except ImportError:
        log.error("openai package not installed")
        return []

    user_msg = _build_user_prompt(markets)

    try:
        response = client.chat.completions.create(
            model=cfg.llm.model_name,
            messages=[
                {"role": "system", "content": _SYSTEM_PROMPT},
                {"role": "user", "content": user_msg},
            ],
            max_tokens=cfg.llm.max_tokens,
            temperature=cfg.llm.temperature,
        )
        content = response.choices[0].message.content.strip()
    except Exception as e:
        log.error(f"LLM API call failed: {e}")
        return []

    # Parse JSON from response (handle markdown fences)
    if content.startswith("```"):
        lines = content.split("\n")
        content = "\n".join(
            l for l in lines if not l.strip().startswith("```")
        )

    try:
        parsed = json.loads(content)
        results = parsed.get("results", [])
    except json.JSONDecodeError as e:
        log.warning(f"LLM response is not valid JSON (likely truncated): {e}")
        log.debug(f"Raw response ({len(content)} chars): {content[:500]}…")
        # Attempt to salvage complete entries from truncated JSON
        results = _salvage_truncated_json(content)
        if results:
            log.info(f"Salvaged {len(results)} complete entries from truncated response")
        else:
            log.error("Could not salvage any entries from truncated response")
            return []

    return results


# ---------------------------------------------------------------------------
# Main mapper
# ---------------------------------------------------------------------------

class LLMMapper:
    """Orchestrate LLM-based ticker mapping with caching."""

    def __init__(self, cfg: AppConfig):
        self.cfg = cfg
        self.cache_dir = cfg.llm.cache_dir
        self.cache = _load_cache(self.cache_dir)
        self.dry_run = cfg.llm.dry_run

    def map_markets(
        self, markets: List[Dict[str, Any]], ticker_validator=None
    ) -> List[Dict[str, Any]]:
        """
        Map a list of markets to tickers.
        - Skips markets already in cache.
        - Batches remaining markets per cfg.llm.batch_size.
        - Validates proposed tickers via ticker_validator (if provided).
        Returns list of mapping results.
        """
        if not self.cfg.llm.enabled:
            log.info("LLM mapping disabled in config")
            return []

        # Separate cached vs. uncached
        to_map = []
        cached_results = []
        for m in markets:
            mid = m["market_id"]
            if mid in self.cache:
                cached_results.append(self.cache[mid])
                log.debug(f"Cache hit for market {mid}")
            else:
                to_map.append(m)

        log.info(
            f"LLM mapping: {len(cached_results)} cached, {len(to_map)} need mapping"
        )

        # Respect max_markets_per_llm_run
        to_map = to_map[: self.cfg.llm.max_markets_per_llm_run]

        if not to_map:
            return cached_results

        # Batch and call LLM
        batch_size = self.cfg.llm.batch_size
        new_results = []

        for i in range(0, len(to_map), batch_size):
            batch = to_map[i : i + batch_size]
            batch_ids = [m["market_id"] for m in batch]
            bid = _cache_key(batch_ids)

            log.info(f"LLM batch {i // batch_size + 1}: {len(batch)} markets")

            if self.dry_run:
                log.info("[DRY RUN] Would call LLM for:")
                for m in batch:
                    log.info(f"  {m['market_id']}: {m.get('question_text', '')[:80]}")
                continue

            results = call_llm_batch(batch, self.cfg)

            # Validate tickers
            for r in results:
                ticker = r.get("ticker", "NONE")
                if ticker != "NONE" and ticker_validator:
                    if not ticker_validator(ticker):
                        log.warning(
                            f"Ticker {ticker} failed validation for market {r.get('market_id')}; "
                            f"forcing NONE"
                        )
                        r["ticker"] = "NONE"

            # Cache this batch
            payload = {"batch_id": bid, "results": results}
            _save_cache(self.cache_dir, bid, payload)
            for r in results:
                mid = r.get("market_id")
                if mid:
                    self.cache[mid] = r

            new_results.extend(results)

        all_results = cached_results + new_results
        log.info(f"LLM mapping complete: {len(all_results)} total results")
        return all_results
