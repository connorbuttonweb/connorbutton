"""
pre_classifier.py — Cheap LLM pre-screen to identify which Polymarket
markets have ANY plausible connection to a tradable financial asset.

This runs BEFORE the full LLM mapper and uses a single, compact prompt
to classify markets in large batches (50+ at a time), drastically reducing
the number of wasted mapping calls.
"""

import json
from typing import Any, Dict, List

from src.config_loader import AppConfig, get_openai_key
from src.logging_utils import get_logger

log = get_logger("pre_classifier")

_CLASSIFIER_PROMPT = """You are a financial relevance classifier. For each prediction market question, 
answer YES if the outcome could plausibly move ANY tradable financial asset (stocks, bonds, commodities, 
crypto, currencies, ETFs) — even indirectly. Answer NO only for pure entertainment, sports results, 
celebrity gossip, or political questions with zero economic implications.

Be INCLUSIVE. Examples of YES:
- "Will there be a US recession?" → YES (SPY, bonds)
- "Russia-Ukraine ceasefire?" → YES (oil, defense stocks, European equities)
- "Will Trump visit China?" → YES (trade implications, FXI, tariff-sensitive stocks)
- "Will China invade Taiwan?" → YES (semiconductors, FXI, defense)
- "Will OpenAI launch hardware?" → YES (tech sector, AI stocks)
- "Government shutdown?" → YES (treasuries, dollar)
- "Fed rate cuts?" → YES (TLT, SPY, everything)
- "Bitcoin hit $1M?" → YES (BTC-USD)
- "MegaETH market cap?" → YES (ETH-USD)
- "Nvidia largest company?" → YES (NVDA)

Examples of NO:
- "Will X win the NBA MVP?" → NO
- "Will Taylor Swift tour in 2026?" → NO
- "Harvey Weinstein sentenced?" → NO
- "GTA VI released?" → NO (it's a game release, not a tradable event)
- "Will X win the 2028 nomination?" → NO (pure politics, no direct asset link)
- "Will Italy qualify for FIFA World Cup?" → NO

Respond with ONLY a JSON array of objects: [{"id": "<market_id>", "fin": true/false}]
Keep it compact — no reasoning needed."""


def pre_classify_markets(
    markets: List[Dict[str, Any]],
    cfg: AppConfig,
    batch_size: int = 50,
) -> List[Dict[str, Any]]:
    """
    Pre-classify markets as financially relevant or not.
    Returns only the markets classified as financially relevant.
    """
    api_key = get_openai_key()
    if not api_key:
        log.warning("No OPENAI_API_KEY — skipping pre-classification, passing all markets through")
        return markets

    try:
        from openai import OpenAI
        client = OpenAI(api_key=api_key)
    except ImportError:
        log.warning("openai not installed — skipping pre-classification")
        return markets

    financial_ids = set()
    total = len(markets)

    for i in range(0, total, batch_size):
        batch = markets[i : i + batch_size]

        # Build compact prompt — just IDs and questions
        lines = []
        for m in batch:
            mid = m["market_id"]
            q = m.get("question_text", "")[:120]  # truncate long questions
            lines.append(f'{mid}: {q}')
        user_msg = "\n".join(lines)

        try:
            response = client.chat.completions.create(
                model=cfg.llm.model_name,
                messages=[
                    {"role": "system", "content": _CLASSIFIER_PROMPT},
                    {"role": "user", "content": user_msg},
                ],
                max_tokens=2048,  # compact output — just IDs and booleans
                temperature=0.0,
            )
            content = response.choices[0].message.content.strip()
        except Exception as e:
            log.error(f"Pre-classifier API call failed: {e}")
            # On failure, pass all markets through (fail open)
            for m in batch:
                financial_ids.add(m["market_id"])
            continue

        # Parse response
        if content.startswith("```"):
            content_lines = content.split("\n")
            content = "\n".join(l for l in content_lines if not l.strip().startswith("```"))

        try:
            results = json.loads(content)
        except json.JSONDecodeError:
            # Try to salvage partial JSON
            try:
                # Sometimes the model wraps in {"results": [...]}
                parsed = json.loads(content)
                if isinstance(parsed, dict):
                    results = parsed.get("results", [])
                else:
                    results = parsed
            except Exception:
                log.warning(f"Pre-classifier JSON parse failed for batch {i // batch_size + 1}, passing all through")
                for m in batch:
                    financial_ids.add(m["market_id"])
                continue

        for entry in results:
            if isinstance(entry, dict) and entry.get("fin", False):
                mid = entry.get("id", "")
                if mid:
                    financial_ids.add(mid)

        batch_fin = sum(1 for e in results if isinstance(e, dict) and e.get("fin", False))
        log.info(
            f"Pre-classifier batch {i // batch_size + 1}: "
            f"{batch_fin}/{len(batch)} classified as financial"
        )

    # Filter to financial markets only
    financial_markets = [m for m in markets if m["market_id"] in financial_ids]

    log.info(
        f"Pre-classification complete: {len(financial_markets)}/{total} markets "
        f"classified as financially relevant"
    )

    return financial_markets
